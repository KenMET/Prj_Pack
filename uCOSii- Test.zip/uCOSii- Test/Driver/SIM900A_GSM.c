#include "SIM900A_GSM.h"
#include "usart.h"


unsigned char *SMS_Num="\"+8613010591500\"";//�������ĺ� 
uint8_t Send_Phone[25]="AT+CMGS=\"           \"";





void Wait_SIM900A_Reg(void)
{
	Send_AT_Cmd("ATE0","OK",3,150);	
	Usart2_SendString("REG\n");
	while(Found_Place1(Got_Usart1_Data,",1") == 0 && Found_Place1(Got_Usart1_Data,",5") == 0)
	{
		Clean_Str(Got_Usart1_Data);
		Usart1_Finish = 0;
		Usart1_Situation = 0;
		Usart1_SendString("AT+CREG?");
		Usart1_SendString("\r\n");
		Delay_ms(100);			
	}
	Clean_Str(Got_Usart1_Data);
	Usart1_Finish = 0;
	Usart1_Situation = 0;

}



void Send_Message(unsigned char *str)
{
	unsigned char k=0;
	u32 FLASH_addr;
	uint16_t Phone_Str[15];
	unsigned char over[3]={0x1a,0xd,0xa};
	FLASH_addr = STM32_FLASH_Number;
	while(STMFLASH_ReadHalfWord(FLASH_addr) != '\0')
	{
		*(Phone_Str+k) = STMFLASH_ReadHalfWord(FLASH_addr);
		FLASH_addr+=2;
		k++;
	}
	for(k=0;k<11;k++)
		Send_Phone[k+9] = *((uint8_t*)Phone_Str+k);	
	Send_AT_Cmd(Send_Phone,">",1,100);   
	Usart1_SendString(str);								  //���Ͷ������� 
	Usart1_SendString(over);
}
























































