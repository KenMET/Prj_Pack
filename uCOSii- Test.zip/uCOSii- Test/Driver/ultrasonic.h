#ifndef __ultrasonic_H_
#define __ultrasonic_H_

#include "sys.h"
#include "stm32f10x.h"
#include "stm32f10x_exti.h"

#define	TRIG_PORT      GPIOB		//TRIG       
#define	ECHO_PORT      GPIOB		//ECHO 

/**************IO�ڶ���************/
#define	TRIG_PIN       GPIO_Pin_14   //TRIG       
#define	ECHO_PIN       GPIO_Pin_15	//ECHO 

extern void Ultrasonic_Init(void);
extern void Ultrasonic_StartMeasure(void);

#endif

