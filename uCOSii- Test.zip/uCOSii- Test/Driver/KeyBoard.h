#ifndef __KeyBoard_H_
#define __KeyBoard_H_

#include"stm32f10x.h"
#include"stm32f10x_conf.h"

//4X4����ʹ��PA8~PA15
/*************������ʹ�õ�IO��**************/
#define RCC_Key 	RCC_APB2Periph_GPIOA	
#define GPIO_Key 	GPIOA
/**************8λKey_I/O��IO�ڶ���************/
#define PIN_Key_L 	(GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_2 | GPIO_Pin_3)
#define PIN_Key_H 	(GPIO_Pin_4 | GPIO_Pin_5 | GPIO_Pin_6 | GPIO_Pin_7)

extern void KeyScan(void);
extern void KeyBoard_Init(void);
extern unsigned char real_key(unsigned char KEY);

#endif
