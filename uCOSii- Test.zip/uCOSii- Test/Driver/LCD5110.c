#include "LCD5110.h"
#include "Delay.h"
#include "asclldata.h"


void GPIO_Configuration_LCD()
{
	  GPIO_InitTypeDef  GPIO_InitStructure_LCD;	
	  RCC_APB2PeriphClockCmd(RCC_LCD5110, ENABLE);
	  GPIO_InitStructure_LCD.GPIO_Pin = GPIO_Pin_5|GPIO_Pin_6|GPIO_Pin_7|GPIO_Pin_8|GPIO_Pin_9;
	  GPIO_InitStructure_LCD.GPIO_Mode = GPIO_Mode_Out_PP; 
	  GPIO_InitStructure_LCD.GPIO_Speed = GPIO_Speed_50MHz;	
	  GPIO_Init(GPIO_LCD5110, &GPIO_InitStructure_LCD);
}

/*-----------------------------------------------------------------------
LCD_write_byte    : ʹ��SPI�ӿ�д���ݵ�LCD
���������dat    ��д������ݣ�
          command ��д����/����ѡ��
-----------------------------------------------------------------------*/
void LCD_write_byte(unsigned char dat, unsigned char command)
{
    unsigned char i;
    LCD_CE = 0;   
    if (command == 0)
     	LCD_DC = 0;
    else
     	LCD_DC = 1;
	for(i=0;i<8;i++)
	{
		if(dat&0x80)
			SDIN = 1;
		else
			SDIN = 0;
		SCLK = 0;
		dat = dat << 1;
		SCLK = 1;
	}
     LCD_CE = 1;
}

void LCD_init(void)
{
	   GPIO_Configuration_LCD();
	   LCD_RST = 1;
	   SCLK = 1;
	   SDIN = 1;
	   LCD_DC = 1;
	   LCD_CE = 1 ;
	   Delay_ms(10);
	   LCD_RST = 0;
	   Delay_us(1);
	   LCD_RST = 1;
	   LCD_CE = 0;
	   Delay_us(1);
	   LCD_CE = 1;						
	   Delay_us(1);
	   LCD_write_byte(0x21, 0);	// ʹ����չ��������LCDģʽ
	   LCD_write_byte(0xc8, 0);	// ����ƫ�õ�ѹ
	   LCD_write_byte(0x06, 0);	// �¶�У��
	   LCD_write_byte(0x13, 0);	// 1:48
	   LCD_write_byte(0x20, 0);	// ʹ�û�������
	   LCD_clear();	        // ����
	   LCD_write_byte(0x0c, 0);	// �趨��ʾģʽ��������ʾ
	   LCD_CE = 0;
	   LCD_clear();
}



void LCD_clear(void)
{
    unsigned int i;

    LCD_write_byte(0x0c, 0);			
    LCD_write_byte(0x80, 0);			

    for (i=0; i<504; i++)
      LCD_write_byte(0, 1);			
}




void LCD_set_XY(unsigned char XX, unsigned char YY)
{
    LCD_write_byte(0x40 | YY, 0);		// column
    LCD_write_byte(0x80 | (XX*6), 0);          	// row
}




void LCD_write_char(unsigned char c)
{
    unsigned char line;

    c -= 32;

    for (line=0; line<6; line++)
      LCD_write_byte(asclldata[c][line], 1);
}



/*-----------------------------------------------------------------------
LCD_write_String  : Ӣ���ַ�����ʾ����
���������*s      ��Ӣ���ַ���ָ�룻
          X��Y    : ��ʾ�ַ�����λ��,x 0-83 ,y 0-5	
-----------------------------------------------------------------------*/
void LCD_Write_String(unsigned char X,unsigned char Y,unsigned char *s)
{
    LCD_set_XY(X,Y);
    while (*s) 
    {
	 	LCD_write_char(*s++);
    }
}


/*-----------------------------------------------------------------------
LCD_write_String  : �������ͱ�������ʾ����
���������NUM      �����ͱ���ָ�룻
          X��Y    : ��ʾ�ַ�����λ��,x 0-83 ,y 0-5	
-----------------------------------------------------------------------*/
void LCD_Write_Int(unsigned char X,unsigned char Y,int NUM)
{
	unsigned char Number_write[7];
	if ((NUM) < 0)
	{
		NUM = -(NUM);
		Number_write[0] = '-';
	}
	else
		Number_write[0] = ' ';

	if ((NUM) >= 10000)
	{
		Number_write[1] = (NUM) / 10000 + 0x30;
		Number_write[2] = ((NUM) % 10000) / 1000 + 0x30;
		Number_write[3] = ((NUM) % 1000) / 100 + 0x30;
		Number_write[4] = ((NUM) % 100) / 10 + 0x30;
		Number_write[5] = (NUM) % 10 + 0x30;
		Number_write[6] = '\0';	
	}
	else if((NUM) >= 1000 && (NUM) < 10000)
	{
		Number_write[1] = (NUM) / 1000 + 0x30;
		Number_write[2] = ((NUM) % 1000) / 100 + 0x30;
		Number_write[3] = ((NUM) % 100) / 10 + 0x30;
		Number_write[4] = (NUM) % 10 + 0x30;
	    Number_write[5] = ' ';
		Number_write[6] = '\0';		
	}
	else if((NUM) >= 100 && (NUM) < 1000)
	{
		Number_write[1] = (NUM) / 100 + 0x30;
		Number_write[2] = ((NUM) % 100) / 10 + 0x30;
		Number_write[3] = (NUM) % 10 + 0x30;
		Number_write[4] = ' ';
		Number_write[5] = ' ';
		Number_write[6] = '\0';		
	}
	else if((NUM) >= 10 && (NUM) < 100)
	{
		Number_write[1] = (NUM) / 10 + 0x30;
		Number_write[2] = (NUM) % 10 + 0x30;
		Number_write[3] = ' ';
		Number_write[4] = ' ';
		Number_write[5] = ' ';
		Number_write[6] = '\0';		
	}
	else if((NUM) < 10)
	{
		Number_write[1] = (NUM) + 0x30;
		Number_write[2] = ' ';
		Number_write[3] = ' ';
		Number_write[4] = ' ';
		Number_write[5] = ' ';
		Number_write[6] = '\0';		
	}
	LCD_Write_String(X,Y,Number_write);
}



/*-----------------------------------------------------------------------
LCD_write_String  : �����ͱ�������ʾ����
���������NUM      �����ͱ���ָ�룻
          X��Y    : ��ʾ�ַ�����λ��,x 0-83 ,y 0-5	
-----------------------------------------------------------------------*/
void LCD_Write_Natural_Int(unsigned char X,unsigned char Y,int NUM)
{
	unsigned char Number_write[6];
	if ((NUM) >= 10000)
	{
		Number_write[0] = (NUM) / 10000 + 0x30;
		Number_write[1] = ((NUM) % 10000) / 1000 + 0x30;
		Number_write[2] = ((NUM) % 1000) / 100 + 0x30;
		Number_write[3] = ((NUM) % 100) / 10 + 0x30;
		Number_write[4] = (NUM) % 10 + 0x30;
		Number_write[5] = '\0';	
	}
	else if((NUM) >= 1000 && (NUM) < 10000)
	{
		Number_write[0] = (NUM) / 1000 + 0x30;
		Number_write[1] = ((NUM) % 1000) / 100 + 0x30;
		Number_write[2] = ((NUM) % 100) / 10 + 0x30;
		Number_write[3] = (NUM) % 10 + 0x30;
	    Number_write[4] = ' ';
		Number_write[5] = '\0';		
	}
	else if((NUM) >= 100 && (NUM) < 1000)
	{
		Number_write[0] = (NUM) / 100 + 0x30;
		Number_write[1] = ((NUM) % 100) / 10 + 0x30;
		Number_write[2] = (NUM) % 10 + 0x30;
		Number_write[3] = ' ';
		Number_write[4] = ' ';
		Number_write[5] = '\0';		
	}
	else if((NUM) >= 10 && (NUM) < 100)
	{
		Number_write[0] = (NUM) / 10 + 0x30;
		Number_write[1] = (NUM) % 10 + 0x30;
		Number_write[2] = ' ';
		Number_write[3] = ' ';
		Number_write[4] = ' ';
		Number_write[5] = '\0';		
	}
	else if((NUM) < 10)
	{
		Number_write[0] = (NUM) + 0x30;
		Number_write[1] = ' ';
		Number_write[2] = ' ';
		Number_write[3] = ' ';
		Number_write[4] = ' ';
		Number_write[5] = '\0';		
	}
	LCD_Write_String(X,Y,Number_write);
}





