#ifndef _EXTI_H_
#define _EXTI_H_
#include "stm32f10x.h"
#include "usart.h"
#include "NRF24l01.h"

#define GPIO_Pin_EXTI 					GPIO_Pin_6
#define GPIO_PinSourceEXTI 			GPIO_PinSource6
#define GPIO_PortSourceEXTI 		GPIO_PortSourceGPIOB
#define EXTI_LINE 							EXTI_Line6



///////////FreeRTOS///////////////////////////////
extern void Task_Exti(void *data);


#endif
