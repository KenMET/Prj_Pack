#ifndef __Ir_H_
#define __Ir_H_

#include "sys.h"
#include "PWM.h"
#include "usart.h"
#include "Delay.h"
#include "stm32f10x.h"
#include "stm32f10x_tim.h"
#include "stm32f10x_exti.h"
#include "stm32f10x_flash.h"

#define IRDA_ID 0
#define	Ir_PORT      GPIOB		       
#define	RCC_Ir		 RCC_APB2Periph_GPIOB
#define	GPIO_Ir_PS	 GPIO_PortSourceGPIOB
/**************IO�ڶ���************/
#define	Ir_PIN       		GPIO_Pin_1



#define Ir_Get_PIN		PBin(1)


extern uint8_t  Mode_Ir;	  /* �����ն˹���ģʽ */
extern uint8_t  End_Ir;	  /* һ֡���ݽ�����ɱ�־ */
extern uint8_t  Study_Ir;	  /* ѧϰ�������־ */

extern uint8_t* Get_Between(unsigned char *Left,unsigned char *Words,unsigned char *Right);
extern uint16_t Found_Place1(unsigned char *Words,unsigned char *word);
extern uint16_t Found_Place0(unsigned char *Words,unsigned char *word);


extern void Ir_Init(void);
extern void Ir_Send(uint8_t *p);
extern void Copy_Str(unsigned char *Words,unsigned char *ToWho);

#endif

