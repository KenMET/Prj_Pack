#include "User_Code.h"
#include "Bat_Data.h"



unsigned short Bat_V,Res_A,Supply_V;

bool Connect_Sta,Charge_Sta;
void Connect_Bat(bool Sta)
{
	Connect_Sta = Sta;
	if(Sta==Connect)
		Ctrl2 = 1;
	else
		Ctrl2 = 0;
}

void Charge_Or_Not(bool Sta)
{
	Charge_Sta = Sta;
	if(Sta==Charge)
		Ctrl1 = 1;
	else
		Ctrl1 = 0;
}

double Min(double A,double B)
{
	if(A>B)
		return B;
	return A;
}
double Max(double A,double B)
{
	if(A<B)
		return B;
	return A;
}

double Fun_Abs(double A)
{
	if(A < 0)
		return -A;
	return A;
}
int16_t Adv(int16_t *Data,uint16_t Len)	//�������е�����ƽ��ֵ
{
	uint32_t k,SUM=0;
	for(k=0;k<Len;k++)
		SUM += Data[k];
	SUM = SUM / Len;
	return SUM;
}

double last_V;
double p_last_V;
double KalmanFilter_V(const double ResrcData,
				double ProcessNiose_Q,double MeasureNoise_R,double InitialPrediction)
{
	double R = MeasureNoise_R;
	double Q = ProcessNiose_Q;
	double p_mid ;
	double p_now;
	double kg; 
	
	
	double mid = last_V;
	double now;     

	mid=last_V; //x_last=x(k-1|k-1),x_mid=x(k|k-1)
	p_mid=p_last_V+Q; //p_mid=p(k|k-1),p_last=p(k-1|k-1),Q=����
	kg=p_mid/(p_mid+R); //kg?kalman filter,RΪ����
	now=mid+kg*(ResrcData-mid);//���Ƴ�����ֵ
	 
	p_now=(1-kg)*p_mid;//����ֵ��Ӧ��covariance 

	p_last_V = p_now; //����covariance
	last_V = now; 		//����ϵͳ״ֵ̬

	return now;               
}
double last_A;
double p_last_A;
double KalmanFilter_A(const double ResrcData,
				double ProcessNiose_Q,double MeasureNoise_R,double InitialPrediction)
{
	double R = MeasureNoise_R;
	double Q = ProcessNiose_Q;
	double p_mid ;
	double p_now;
	double kg; 
	
	
	double mid = last_A;
	double now;     

	mid=last_A; //x_last=x(k-1|k-1),x_mid=x(k|k-1)
	p_mid=p_last_A+Q; //p_mid=p(k|k-1),p_last=p(k-1|k-1),Q=����
	kg=p_mid/(p_mid+R); //kg?kalman filter,RΪ����
	now=mid+kg*(ResrcData-mid);//���Ƴ�����ֵ
	 
	p_now=(1-kg)*p_mid;//����ֵ��Ӧ��covariance 

	p_last_A = p_now; //����covariance
	last_A = now; 		//����ϵͳ״ֵ̬

	return now;               
}
#define MFC_Len 12
void Send_Data_To_MFC(unsigned char CMD,unsigned short V
		,unsigned short Left,unsigned short Present,unsigned short Cnt)
{
	signed char Check=0,k;
	char Data[MFC_Len+1];
	Data[0] = '#';
	Data[1] = CMD;
	Data[2] = (V >> 8) & 0xff;
	Data[3] =  V & 0xff;
	Data[4] = (Left >> 8) & 0xff;
	Data[5] =  Left & 0xff;
	Data[6] = (Present >> 8) & 0xff;
	Data[7] =  Present & 0xff;
	Data[8] = (Cnt >> 8) & 0xff;
	Data[9] =  Cnt & 0xff;
	
	for(k=0;k<MFC_Len-3;k++)
		Check += (signed char)Data[k+1];
	Data[10] = --Check;
	Data[11] = '@';
	Usart1_SendLen(Data,MFC_Len);
}



float Caculat_AH(unsigned short A,float Sec)
{
	static float Temp;
	Temp = ((float)A/100) * Sec ;
	return Temp;
}



unsigned short Bat_V_Filter[Bat_Data4_CNT]={0};

//�Էŵ����ݽ���ƽ������
void Caculat_Filter(unsigned short *Dat,unsigned char Dat_Ch)
{
	unsigned short k=0;
	switch(Dat_Ch)
	{
		case 1:
		{
			last_V = Bat_Dat4[k][0];
			for(k=0;k<Bat_Data1_CNT;k++)
				Dat[k] = KalmanFilter_V( Bat_Dat1[k][0] , KALMAN_Q, KALMAN_R, 30 );		
		}break;
		case 2:
		{
			last_V = Bat_Dat2[k][0];
			for(k=0;k<Bat_Data2_CNT;k++)
				Dat[k] = KalmanFilter_V( Bat_Dat2[k][0] , KALMAN_Q, KALMAN_R, 30 );		
		}break;
		case 3:
		{
			last_V = Bat_Dat3[k][0];
			for(k=0;k<Bat_Data3_CNT;k++)
				Dat[k] = KalmanFilter_V( Bat_Dat3[k][0] , KALMAN_Q, KALMAN_R, 30 );		
		}break;
		case 4:
		{
			last_V = Bat_Dat4[k][0];
			for(k=0;k<Bat_Data4_CNT;k++)
				Dat[k] = KalmanFilter_V( Bat_Dat4[k][0] , KALMAN_Q, KALMAN_R, 30 );		
		}break;
	}
}

float Caculat_AH_Totol(unsigned char Group)
{
	unsigned short k=0,CNT = Bat_Data2_CNT;
	float Sum_Watt=0;
	switch(Group)
	{
		case 1: CNT = Bat_Data1_CNT;	break;
		case 2: CNT = Bat_Data2_CNT;	break;
		case 3: CNT = Bat_Data3_CNT;	break;
		case 4: CNT = Bat_Data4_CNT;	break;
	}
	
	for(k=0;k<CNT;k++)
	{
		switch(Group)//ʱ�����
		{
			case 1:	Sum_Watt += Caculat_AH(Bat_Dat1[k][1],5);	break;
			case 2:	Sum_Watt += Caculat_AH(Bat_Dat2[k][1],5);	break;
			case 3:	Sum_Watt += Caculat_AH(Bat_Dat3[k][1],5);	break;
			case 4:	Sum_Watt += Caculat_AH(Bat_Dat4[k][1],5);	break;
		}
	}
	Sum_Watt*=(((signed short)Present_Temp-(signed short)Standard_Tem)*Ratio+1);
	return Sum_Watt;
}

#define V_Test		FALSE
#define AH_Test		TRUE
float AH_Left,AH_Uesd=0;
float AH_Totol1=0,AH_Totol2=0,AH_Totol3=0,AH_Totol4=0;
float Caculat_Present(bool V_Or_AH,float AH_Now)
{
	float Present1,Present2,Present3,Present4;
	unsigned short k=0,Bat_V_Now;
	for(k=0;k<500;k++)	//5s�˲����ŵó����ڵĵ�ѹֵ
	{
		Bat_V_Now = KalmanFilter_V( Bat_V , KALMAN_Q, KALMAN_R, 30 );
		Delay_ms(10);
	}
	if(Bat_V_Now < ((One_Bat_Volta*Bat_Number*Low_Bat)*100))	//�����ʱ��ѹ��������޶�ֵ,ֱ�ӷ���0%
		return 0;
	if(V_Or_AH == V_Test)		//ȡ��ѹ���ݵİٷֱ�
	{
		k=0;
		while(Bat_V_Now < Bat_V_Filter[k] && k < Bat_Data4_CNT){k++;}
		Present4  = (float)(Bat_Data4_CNT - k);
		Present4 /= (float)Bat_Data4_CNT;
		k=0;
		Caculat_Filter(Bat_V_Filter,1);
		while(Bat_V_Now < Bat_V_Filter[k] && k < Bat_Data1_CNT){k++;}
		Present1  = (float)(Bat_Data1_CNT - k);
		Present1 /= (float)Bat_Data1_CNT;
//		k=0;
//		Caculat_Filter(Bat_V_Filter,2);
//		while(Bat_V_Now < Bat_V_Filter[k] && k < Bat_Data2_CNT){k++;}
//		Present2  = (float)(Bat_Data2_CNT - k);
//		Present2 /= (float)Bat_Data2_CNT;
		k=0;
		Caculat_Filter(Bat_V_Filter,3);
		while(Bat_V_Now < Bat_V_Filter[k] && k < Bat_Data3_CNT){k++;}
		Present3  = (float)(Bat_Data3_CNT - k);
		Present3 /= (float)Bat_Data3_CNT;
		
		return (Present1+Present3+Present4)/3;	
	}
	else	//ȡ���ַ�ʣ��ٷֱȣ���ƽ��
	{
//		AH_Totol = AH_Totol1 
//		* (((signed short)Present_Temp-(signed short)Standard_Tem)*Ratio+1);
		Present1 = AH_Now / AH_Totol1;
//		AH_Totol = AH_Totol2 
//		* (((signed short)Present_Temp-(signed short)Standard_Tem)*Ratio+1);
		Present2 = AH_Now / AH_Totol2;
//		AH_Totol = AH_Totol3
//		* (((signed short)Present_Temp-(signed short)Standard_Tem)*Ratio+1);
		Present3 = AH_Now / AH_Totol3;
//		AH_Totol = AH_Totol4 
//		* (((signed short)Present_Temp-(signed short)Standard_Tem)*Ratio+1);
		Present4 = AH_Now / AH_Totol4;
		
		return (Present1+Present2+Present3+Present4)/4;	
	}
}


bool Test_Enable = FALSE;
//User���� ���ڼ�����ʣ��
OS_STK User_TASK_STK[User_STK_SIZE];
void User_Task(void *pdata)
{	 	
	bool First = TRUE;
	float Present,Present_Last=1,Present_Fornow,Now_AH_Ues,Sec_Used;
	unsigned short V_Last=0;
	Caculat_Filter(Bat_V_Filter,4);
	AH_Totol1 = Caculat_AH_Totol(1);
	AH_Totol2 = Caculat_AH_Totol(2);
	AH_Totol3 = Caculat_AH_Totol(3);
	AH_Totol4 = Caculat_AH_Totol(4);
	printf("1:%5.2f 2:%5.2f 3:%5.2f 4:%5.2f\n",AH_Totol1,AH_Totol2,AH_Totol3,AH_Totol4);
	Log_Uartx("Task Of User Created...\n");
	while(1)
	{
		
		Present_Temp = DS18B20_Get_Temp();
		if(Test_Enable==TRUE)
		{
			if(First==TRUE)
			{
				First = FALSE;
				TIM4_CNT = 0;
				Delay_ms(2000);	//�ȴ���ѹ����
				while(	Fun_Abs((signed short)V_Last - (signed short)Bat_V) > 50)	//�ȴ���ѹ�ȶ�
				{Delay_ms(2000);V_Last = Bat_V;}
				//printf("Last_V:%d ",V_Last);
				do
				{//�Ե�ѹ�������������97%��˵����غܳ��㣬��100%�滻���ȴ����ص�99%����
					Present = Caculat_Present(V_Test,0);
					//printf("Present:%.4f\n",Present);	
					Delay_ms(1000);
				}while(Present > 0.97);		
				AH_Left = Present * ((AH_Totol1+AH_Totol3+AH_Totol4)/3);//�������������������Ϊ�������
				//printf("Now AH_Left:%.2f\n",AH_Left);	
			}

			if(Res_A > 30)		
			{
				TIM3->CR1&=0xfe;    //Close TIM3
				Sec_Used = (float)(TIM3_CNT*10000 + TIM3->CNT)/10000;
				Now_AH_Ues = Caculat_AH(Res_A,Sec_Used);
				//printf("Sec:%.3fs AH_Used:%.2f\n",Sec_Used,Now_AH_Ues);
				AH_Uesd += Now_AH_Ues;
				AH_Left -= Now_AH_Ues;
				TIM3_CNT = 0;
				TIM3->CNT = 0;
				TIM3->CR1|=0x01;    //Open TIM3
			}
			//printf("Now_V:%d   Now_A:%d\n",Bat_V,Res_A);	
			
			Present = Caculat_Present(AH_Test,AH_Left);
			Present_Fornow = Caculat_Present(V_Test,0);
			if(Present > 1)	Present = 1;
			//printf("Present:%.4f Fornow:%.4f  ",Present,Present_Fornow);
			if(Fun_Abs(Present - Present_Fornow) > 0.05)	//��ѹ������ʱ����ַ����������5%��ȡ����ֵ������ѹ���㷨���
			{
				Present = (Present_Fornow + Present)/2;
				AH_Left = Present * ((AH_Totol1+AH_Totol3+AH_Totol4)/3);	//���¶���ʣ�����
			}
			if(Present > Present_Last)	//��ֹ�ٷֱ�������
				Present = Present_Last;
			else
				Present_Last = Present;
			//printf("Tem:%d\n",Present_Temp);
			//�õ����ʣ��ʱ��
			Present_TIME = ((Bat_Data1_CNT+Bat_Data3_CNT+Bat_Data4_CNT) / 3) * Present / 12;
			Present_OLED = (unsigned short)(Present * 10000);
			//printf("After_Present :%.4f  AH:%.2f\n*****************\n",Present,AH_Left);
			Send_Data_To_MFC(0x01,Bat_V,Present_TIME,Present*10000,TIM4_CNT);
			if(Present < 0.02)
			{
				Connect_Bat(Disconnect);
				Test_Enable = FALSE;
			}
		}
		else
		{
			TIM4_CNT = 0;
			Delay_ms(1000);
		}
			
		
		
//		for(k=0;k<Bat_Data4_CNT;k++)
//			printf("%d\n",Bat_V_Filter[k]);
	}
	
	
}








