#ifndef _IIC_H_
#define	_IIC_H_

#include "stm32f10x.h"
#include "stm32f10x_i2c.h"
#include "Delay.h"

#include "sys.h"





 
//IIC���в�������
extern void IIC_Init(void);               		 

extern void IIC_Write_Byte(uint8_t addr,uint8_t reg,uint8_t data);





#endif
