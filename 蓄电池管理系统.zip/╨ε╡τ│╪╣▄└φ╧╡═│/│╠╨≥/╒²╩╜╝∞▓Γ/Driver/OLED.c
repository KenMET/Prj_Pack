#include "OLED.h"
#include "OLED_Font.h"



bool OLED_Write_CMD(unsigned char CMD)
{
	IIC_Write_Byte(OLED_ADDRESS,OLED_CMD,CMD);
	return TRUE;
}
bool OLED_Write_DAT(unsigned char DAT)
{
	IIC_Write_Byte(OLED_ADDRESS,OLED_DAT,DAT);
	return TRUE;
}


bool OLED_Init(void)
{
	IIC_Init();
	Delay_ms(200); //�������ʱ����Ҫ
	OLED_Write_CMD(0xAE); //display off
	OLED_Write_CMD(0x20);	//Set Memory Addressing Mode	
	OLED_Write_CMD(0x10);	//00,Horizontal Addressing Mode;01,Vertical Addressing Mode;10,Page Addressing Mode (RESET);11,Invalid
	OLED_Write_CMD(0xb0);	//Set Page Start Address for Page Addressing Mode,0-7
	OLED_Write_CMD(0xc8);	//Set COM Output Scan Direction
	OLED_Write_CMD(0x00); //---set low column address
	OLED_Write_CMD(0x10); //---set high column address
	OLED_Write_CMD(0x40); //--set start line address
	OLED_Write_CMD(0x81); //--set contrast control register
	OLED_Write_CMD(0xff); //���ȵ��� 0x00~0xff
	OLED_Write_CMD(0xa1); //--set segment re-map 0 to 127
	OLED_Write_CMD(0xa6); //--set normal display
	OLED_Write_CMD(0xa8); //--set multiplex ratio(1 to 64)
	OLED_Write_CMD(0x3F); //
	OLED_Write_CMD(0xa4); //0xa4,Output follows RAM content;0xa5,Output ignores RAM content
	OLED_Write_CMD(0xd3); //-set display offset
	OLED_Write_CMD(0x00); //-not offset
	OLED_Write_CMD(0xd5); //--set display clock divide ratio/oscillator frequency
	OLED_Write_CMD(0xf0); //--set divide ratio
	OLED_Write_CMD(0xd9); //--set pre-charge period
	OLED_Write_CMD(0x22); //
	OLED_Write_CMD(0xda); //--set com pins hardware configuration
	OLED_Write_CMD(0x12);
	OLED_Write_CMD(0xdb); //--set vcomh
	OLED_Write_CMD(0x20); //0x20,0.77xVcc
	OLED_Write_CMD(0x8d); //--set DC-DC enable
	OLED_Write_CMD(0x14); //
	OLED_Write_CMD(0xaf); //--turn on oled panel
	OLED_Fill(0x00);
	return TRUE;
}

void OLED_SetPos(unsigned char Page,unsigned char seg)
{//Page :0~7 		seg:0~127
	OLED_Write_CMD(0xB0 + Page);
	OLED_Write_CMD(0x0F & seg);
	OLED_Write_CMD(0x10 | (seg>>4)); 
}


void OLED_Fill(unsigned char fill_Data)//ȫ�����
{
	unsigned char i,j;
	for(i=0;i<8;i++)	//��ҳ���
	{
		OLED_SetPos(i,0);
		for(j=0;j<128;j++)
			OLED_Write_DAT(fill_Data);
	}
}
void OLED_DisplayPIC(uint8_t Page,uint8_t seg	,char cha)
{
	unsigned char k;
	OLED_SetPos(Page,seg);
	for(k=0;k<16;k++)
		OLED_Write_DAT(PIC[cha][k]);
	OLED_SetPos(Page+1,seg);
	for(k=16;k<32;k++)
		OLED_Write_DAT(PIC[cha][k]);
}
void OLED_DisplayChar(uint8_t Page,uint8_t seg	,char cha)
{
	unsigned char k;
	OLED_SetPos(Page,seg);
	for(k=0;k<8;k++)
		OLED_Write_DAT(F8X16[cha-' '][k]);
	OLED_SetPos(Page+1,seg);
	for(k=8;k<16;k++)
		OLED_Write_DAT(F8X16[cha-' '][k]);
}
void OLED_DisplayStr(uint8_t Page,uint8_t seg	,char *Str)
{			//*Str = 'a'
	while(*Str != '\0')
	{
		OLED_DisplayChar(Page,seg,*Str);
		Str++;
		if(seg < 120)
			seg += 8; 	
		else
		{
			seg=0;
			Page+=2;
		}	
	}
}

void Copy_15Str(char* From,char* To)
{
	unsigned char k;
	for(k=0;k<15;k++)
		*(To+k) = *(From+k);
}

unsigned short Present_OLED=0,Present_TIME=0,Present_Temp=0;
OS_STK OLED_TASK_STK[OLED_STK_SIZE];

//OLED����
void OLED_Task(void *pdata)
{	 	
	unsigned char Line_Mod=0;
	unsigned char OLED_CNT=0;
	bool Connect_Mod=FALSE,Charge_Mod=TRUE;
	char Line1[16] = "Voltage: 00.00V";
	char Line2[16] = "Current: 00.00A";
	char Line3[16] = "Supply : 00.00V";
	char Line4[16] = "Left:    78.90%";
	Log_Uartx("Task Of OLED Created...\n");
	while(1)
	{
		Delay_ms(200);
		
		Line1[9]  = (Bat_V % 10000) / 1000 + '0';
		Line1[10] = (Bat_V % 1000) / 100 + '0';
		Line1[12] = (Bat_V % 100) / 10 + '0';
		Line1[13] = Bat_V % 10 + '0';
		if(Line1[9] == '0')
			Line1[9] = ' ';
		

		
		
		
		
		OLED_DisplayStr(0,0,Line1);
		
		
		if(Line_Mod)
		{
			Copy_15Str("Temp   :  00.0  ",Line2);
			Line2[10]  = (Present_Temp % 1000) / 100 + '0';
			Line2[11] = (Present_Temp % 100) / 10 + '0';
			Line2[13] =  Present_Temp % 10 + '0';
			if(Line2[10] == '0')
				Line2[10] = ' ';
			OLED_DisplayStr(2,0,Line2);
			Copy_15Str("Supply : 00.00V",Line3);
			Line3[9]  = (Supply_V % 10000) / 1000 + '0';
			Line3[10] = (Supply_V % 1000) / 100 + '0';
			Line3[12] = (Supply_V % 100) / 10 + '0';
			Line3[13] = Supply_V % 10 + '0';
			if(Line3[9] == '0')
				Line3[9] = ' ';
			OLED_DisplayStr(4,0,Line3);
			
			if(Key == '1')			Connect_Mod = TRUE;
			else if(Key == '3')	Connect_Mod = FALSE;
			else if(Key == '2')	Charge_Mod	= TRUE;
			else if(Key == '4')	Charge_Mod	= FALSE;
			if(Connect_Mod)			OLED_DisplayPIC(6,103,0);
			else								OLED_DisplayStr(6,103,"  ");
			if(Charge_Mod)			OLED_DisplayStr(6,0,"Discharge    ");
			else								OLED_DisplayStr(6,0,"Charge       ");	
		}
		else
		{
			Copy_15Str("Current: 00.00A",Line2);
			Line2[9]  = (Res_A % 10000) / 1000 + '0';
			Line2[10] = (Res_A % 1000) / 100 + '0';
			Line2[12] = (Res_A % 100) / 10 + '0';
			Line2[13] =  Res_A % 10 + '0';
			if(Line2[9] == '0')
				Line2[9] = ' ';
			OLED_DisplayStr(2,0,Line2);
			Copy_15Str("TIME   :  0000m",Line3);
			Line3[10] = (Present_TIME % 10000) / 1000 + '0';
			Line3[11] = (Present_TIME % 1000) / 100 + '0';
			Line3[12] = (Present_TIME % 100) / 10 + '0';
			Line3[13] = Present_TIME % 10 + '0';
			if(Line3[10] == '0')
			{
				Line3[10] = ' ';
				if(Line3[11] == '0')
				{
					Line3[11] = ' ';
					if(Line3[12] == '0')
					{
						Line3[12] = ' ';
					}
				}
			}
			OLED_DisplayStr(4,0,Line3);
			Line4[9]  = (Present_OLED % 10000) / 1000 + '0';
			Line4[10] = (Present_OLED % 1000) / 100 + '0';
			Line4[12] = (Present_OLED % 100) / 10 + '0';
			Line4[13] =  Present_OLED % 10 + '0';
			if(Line4[9] == '0')
				Line4[9] = ' ';
			OLED_DisplayStr(6,0,Line4);
		}
			
		
		if(++OLED_CNT == 15)
		{
			Line_Mod = !Line_Mod;
			OLED_CNT = 0;
		}
	}
}



