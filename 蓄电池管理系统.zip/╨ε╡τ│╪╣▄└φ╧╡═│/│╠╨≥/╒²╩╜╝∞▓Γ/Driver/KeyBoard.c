#include "KeyBoard.h"




void KeyBoard_Init()
{
	GPIO_InitTypeDef GPIO_InitStructure;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);	 //��APB2�����ϵ�GPIOʱ��

	GPIO_InitStructure.GPIO_Pin = PIN_Key;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;		  
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD;		  //PA0~PA3��������
	GPIO_Init(GPIOA, &GPIO_InitStructure);	 	  		  //��ʼ��

}



unsigned char Key = '2';
OS_STK Key_TASK_STK[Key_STK_SIZE];
//Key����
void Key_Task(void *pdata)
{	 	
	Log_Uartx("Task Of Key Created...\n");
	while(1)
	{
		Delay_ms(30);
		if((GPIO_Key->IDR&0x0f) != 0x0f)
		{
			Delay_ms(10);
			if((GPIO_Key->IDR&0x0f) != 0x0f)
			{
				if(Key1 == 0)
				{
					Test_Enable = TRUE;
					Connect_Bat(Connect);
					Key = '1';
				}
				if(Key2 == 0)
				{
					Test_Enable = FALSE;
					Charge_Or_Not(Discharge);
					Key = '2';
				}	
				if(Key3 == 0)
				{
					Test_Enable = FALSE;
					Connect_Bat(Disconnect);
					Key = '3';
				}
				if(Key4 == 0)
				{
					Charge_Or_Not(Charge);
					Key = '4';
				}	
				while((GPIO_Key->IDR&0x0f) != 0x0f) {Delay_ms(100);}
			}	
		}

		
		
	}
}









































