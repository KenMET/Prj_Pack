#include "DS18B20.h"




void DS18B20_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB|RCC_APB2Periph_AFIO, ENABLE);
	

	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13;			
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(GPIOB, &GPIO_InitStructure);
	
	DS_SDA_OUT();
}
//

//��λDS18B20
void DS18B20_Rst(void)	   
{                 
	DS_SDA_OUT();
  DS18B20_SDA_Out=0; //����DQ
  Delay_us(750);    //����750us
  DS18B20_SDA_Out=1; //DQ=1 
	Delay_us(15);     //15US
}
//

//д��һ���ֽ�
void DS18B20_WriteByte(unsigned char dat)  
{  
	u8 j;
	u8 testb;
	DS_SDA_OUT();//SET PA0 OUTPUT;
	for (j=1;j<=8;j++) 
	{
		testb=dat&0x01;
		dat=dat>>1;
		if (testb) 
		{
			DS18B20_SDA_Out=0;// Write 1
			Delay_us(2);                            
			DS18B20_SDA_Out=1;
			Delay_us(60);             
		}
		else 
		{
			DS18B20_SDA_Out=0;// Write 0
			Delay_us(60);             
			DS18B20_SDA_Out=1;
			Delay_us(2);                          
		}
	} 
}
//

//����һλ
unsigned char DS18B20_ReadBit(void)   
{  
	u8 data;
	DS_SDA_OUT();//SET PA0 OUTPUT
  DS18B20_SDA_Out=0; 
	Delay_us(2);
  DS18B20_SDA_Out=1; 
	DS_SDA_IN();//SET PA0 INPUT
	Delay_us(12);
	if(DS18B20_SDA_In)
		data=1;
  else 
		data=0;	 
  Delay_us(50);           
  return data;
}
//
//����һ���ֽ�
unsigned char DS18B20_CH1_ReadByte(void)
{
	unsigned char i,j,dat;
	dat=0;
	for (i=1;i<=8;i++) 
	{
		j=DS18B20_ReadBit();
		dat=(j<<7)|(dat>>1);
	}						    
	return dat;
}
//
//�ȴ�DS18B20�Ļ�Ӧ
//����1:δ��⵽DS18B20�Ĵ���
//����0:����
unsigned char DS18B20_Check(void) 	   
{   
	u8 retry=0;
	DS_SDA_IN();//SET PA0 INPUT	 
  while (DS18B20_SDA_In&&retry<200)
	{
		retry++;
		Delay_us(1);
	}	 
	if(retry>=200)
		return 1;
	else 
		retry=0;
  while (!DS18B20_SDA_In&&retry<240)
	{
		retry++;
		Delay_us(1);
	}
	if(retry>=240)
		return 1;	    
	return 0;
}
//
//��ʼ�¶�ת��
void DS18B20_Start()// ds1820 start convert
{   					

	DS18B20_Rst();	   
	DS18B20_Check();	 
	DS18B20_WriteByte(0xcc);// skip rom
	DS18B20_WriteByte(0x44);// convert			

} 
//

short DS18B20_Get_Temp()
{
	u8 temp;
	u8 TL,TH;
	short tem;
	DS18B20_Start();                    // ds1820 start convert

	DS18B20_Rst();
	DS18B20_Check();	 
	DS18B20_WriteByte(0xcc);// skip rom
	DS18B20_WriteByte(0xbe);// convert	    
	TL=DS18B20_CH1_ReadByte(); // LSB   
	TH=DS18B20_CH1_ReadByte(); // MSB  			

	if(TH>7)
	{
		TH=~TH;
		TL=~TL; 
		temp=0;//�¶�Ϊ��  
	}
	else 
		temp=1;//�¶�Ϊ��	  	  
	tem=TH; //��ø߰�λ
	tem<<=8;    
	tem+=TL;//��õװ�λ
	tem=(float)tem*0.625;//ת��    
	if(tem > -100 && tem < 450)		//���������Χ
	{
		if(temp)			return tem; //�����¶�ֵ
		else 					return -tem;   	
	}
	else
		return 250;
} 
//









