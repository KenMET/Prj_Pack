#include "EXTI.h"


void My_EXTI_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	EXTI_InitTypeDef EXTI_InitStructure;
	NVIC_InitTypeDef NVIC_InitStructure;
	
	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_EXTI;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_Init(GPIOB , &GPIO_InitStructure);
	GPIO_EXTILineConfig(GPIO_PortSourceEXTI , GPIO_PinSourceEXTI);
	
	
	EXTI_InitStructure.EXTI_Line = EXTI_LINE;
	EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
	EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising_Falling;
	EXTI_InitStructure.EXTI_LineCmd = ENABLE;
	EXTI_Init(&EXTI_InitStructure);
	
	
	/* ʹ��EXIT 4ͨ��*/
//	NVIC_InitStructure.NVIC_IRQChannel = EXTI4_IRQn;
//	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 5;
//	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
//	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
//	NVIC_Init(&NVIC_InitStructure); 

	/* ʹ��EXIT 5-9ͨ�� */
	NVIC_InitStructure.NVIC_IRQChannel = EXTI9_5_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);
}
//void EXTI4_IRQHandler(void)
//{
//	if(EXTI_GetITStatus(EXTI_Line4)!=RESET)//�ж�5���ϵ��ж��Ƿ���
//	{		

//			EXTI_ClearITPendingBit(EXTI_Line4);  //��� LINE5 �ϵ��жϱ�־λ
//	} 	
//}


extern uint8_t NRF24L01_RXDATA[RX_PLOAD_WIDTH];

void EXTI9_5_IRQHandler(void)
{
	uint8_t sta = NRF_Read_Reg(NRF_READ_REG + NRFRegSTATUS);	
	if(EXTI_GetITStatus(EXTI_LINE)!=RESET)//�ж�5���ϵ��ж��Ƿ���
	{		
		Usart1_SendString("Exti In....\n\n");
//		if(sta & (1<<RX_DR))//�����ж�
//		{
//			NRF_Read_Buf(0x61,NRF24L01_RXDATA,32);// read receive payload from RX_FIFO buffer
//			NRF_Write_Reg(0x27, 0xff);//���nrf���жϱ�־λ
//		}
//		if(sta & (1<<TX_DS))//������ɲ����յ�Ӧ���ź��ж�
//		{
//		}
//		if(sta & (1<<MAX_RT))//�ﵽ����ط������ж�
//		{
//		}
//		NRF_Write_Reg(0x27, 0xff);//���nrf���жϱ�־λ
		EXTI_ClearITPendingBit(EXTI_LINE);  //��� LINE5 �ϵ��жϱ�־λ
	} 	
}

//////////////////////////////////////////////////////
void Task_Exti(void *data)
{
	portTickType x;
	x = xTaskGetTickCount();
	
	My_EXTI_Init();
	
	while(1)
	{
		
		vTaskDelayUntil(&x,10);
	}

}



