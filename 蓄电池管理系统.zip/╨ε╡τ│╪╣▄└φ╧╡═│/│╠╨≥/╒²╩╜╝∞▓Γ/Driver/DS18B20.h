#ifndef __DS18B20_H__
#define __DS18B20_H__

//UCOSii�����ļ�����
#include "includes.h"

#include "sys.h"
#include "stm32f10x.h"




#define DS_SDA_IN()  {GPIOB->CRH&=0XFF0FFFFF;GPIOB->CRH|=0X00800000;} //����ģʽ
#define DS_SDA_OUT() {GPIOB->CRH&=0XFF0FFFFF;GPIOB->CRH|=0X00300000;} //���ģʽ



#define DS18B20_SDA_Out  PBout(13)
#define DS18B20_SDA_In  	PBin(13)



extern void DS18B20_Init(void);

extern short DS18B20_Get_Temp(void);

#endif


