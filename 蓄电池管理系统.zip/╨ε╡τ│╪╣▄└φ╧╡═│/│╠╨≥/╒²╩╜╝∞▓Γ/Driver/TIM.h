#ifndef __TIM_H_
#define __TIM_H_

//UCOSii�����ļ�����
#include "includes.h"


#include "stm32f10x.h"
#include "stm32f10x_tim.h"
#include "sys.h"

#include "User_Code.h"


#define Samp_Size			40
#define Window_Size		15



extern unsigned int TIM3_CNT,TIM4_CNT;
extern void TIM4_Int_Init(u16 arr,u16 psc);
extern void TIM3_Int_Init(u16 arr,u16 psc);
extern void TIM2_Int_Init(u16 arr,u16 psc);

#endif
