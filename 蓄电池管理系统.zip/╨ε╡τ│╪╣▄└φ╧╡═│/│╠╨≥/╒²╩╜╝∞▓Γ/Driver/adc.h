#ifndef __ADC_H_
#define __ADC_H_

#include "sys.h"
#include "stm32f10x_adc.h"
#include "stm32f10x_dma.h"
#include "delay.h"


#define ADC_Channel_CNT 3


extern int16_t AD_Val[ADC_Channel_CNT+1];
extern int16_t Filter_AD[ADC_Channel_CNT+1];




extern void Adc_Init(void);
extern void DMA_Configuration(void);
extern u16  Get_Adc(u8 ch); 

#endif 
