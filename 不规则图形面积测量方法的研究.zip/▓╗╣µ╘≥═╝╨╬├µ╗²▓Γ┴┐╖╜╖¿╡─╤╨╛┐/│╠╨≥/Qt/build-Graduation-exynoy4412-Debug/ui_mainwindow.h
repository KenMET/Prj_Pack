/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.7.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSplitter>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QPushButton *pushButton;
    QComboBox *comboBox;
    QLabel *label;
    QPushButton *pushButton_2;
    QLabel *label_static1;
    QLabel *label_static2;
    QLabel *label_static3;
    QLabel *label_static4;
    QLabel *label_static5;
    QLabel *label_static6;
    QLabel *label_static7;
    QSplitter *splitter;
    QLabel *label_dat1;
    QLabel *label_dat2;
    QLabel *label_dat3;
    QLabel *label_dat4;
    QLabel *label_dat5;
    QLabel *label_dat6;
    QLabel *label_dat7;
    QLabel *label_dat8;
    QLabel *label_dat9;
    QLabel *label_dat10;
    QLabel *label_w;
    QLabel *label_h;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(480, 272);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        pushButton = new QPushButton(centralWidget);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(0, 210, 71, 71));
        comboBox = new QComboBox(centralWidget);
        comboBox->setObjectName(QStringLiteral("comboBox"));
        comboBox->setGeometry(QRect(-2, 20, 61, 22));
        label = new QLabel(centralWidget);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(0, 0, 59, 21));
        pushButton_2 = new QPushButton(centralWidget);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setGeometry(QRect(0, 140, 71, 61));
        label_static1 = new QLabel(centralWidget);
        label_static1->setObjectName(QStringLiteral("label_static1"));
        label_static1->setGeometry(QRect(170, 0, 21, 16));
        label_static2 = new QLabel(centralWidget);
        label_static2->setObjectName(QStringLiteral("label_static2"));
        label_static2->setGeometry(QRect(210, 0, 21, 16));
        label_static3 = new QLabel(centralWidget);
        label_static3->setObjectName(QStringLiteral("label_static3"));
        label_static3->setGeometry(QRect(250, 0, 31, 16));
        label_static4 = new QLabel(centralWidget);
        label_static4->setObjectName(QStringLiteral("label_static4"));
        label_static4->setGeometry(QRect(290, 0, 31, 16));
        label_static5 = new QLabel(centralWidget);
        label_static5->setObjectName(QStringLiteral("label_static5"));
        label_static5->setGeometry(QRect(330, 0, 41, 16));
        label_static6 = new QLabel(centralWidget);
        label_static6->setObjectName(QStringLiteral("label_static6"));
        label_static6->setGeometry(QRect(380, 0, 41, 16));
        label_static7 = new QLabel(centralWidget);
        label_static7->setObjectName(QStringLiteral("label_static7"));
        label_static7->setGeometry(QRect(430, 0, 51, 16));
        splitter = new QSplitter(centralWidget);
        splitter->setObjectName(QStringLiteral("splitter"));
        splitter->setGeometry(QRect(140, 20, 341, 211));
        splitter->setOrientation(Qt::Vertical);
        label_dat1 = new QLabel(splitter);
        label_dat1->setObjectName(QStringLiteral("label_dat1"));
        splitter->addWidget(label_dat1);
        label_dat2 = new QLabel(splitter);
        label_dat2->setObjectName(QStringLiteral("label_dat2"));
        splitter->addWidget(label_dat2);
        label_dat3 = new QLabel(splitter);
        label_dat3->setObjectName(QStringLiteral("label_dat3"));
        splitter->addWidget(label_dat3);
        label_dat4 = new QLabel(splitter);
        label_dat4->setObjectName(QStringLiteral("label_dat4"));
        splitter->addWidget(label_dat4);
        label_dat5 = new QLabel(splitter);
        label_dat5->setObjectName(QStringLiteral("label_dat5"));
        splitter->addWidget(label_dat5);
        label_dat6 = new QLabel(splitter);
        label_dat6->setObjectName(QStringLiteral("label_dat6"));
        splitter->addWidget(label_dat6);
        label_dat7 = new QLabel(splitter);
        label_dat7->setObjectName(QStringLiteral("label_dat7"));
        splitter->addWidget(label_dat7);
        label_dat8 = new QLabel(splitter);
        label_dat8->setObjectName(QStringLiteral("label_dat8"));
        splitter->addWidget(label_dat8);
        label_dat9 = new QLabel(splitter);
        label_dat9->setObjectName(QStringLiteral("label_dat9"));
        splitter->addWidget(label_dat9);
        label_dat10 = new QLabel(splitter);
        label_dat10->setObjectName(QStringLiteral("label_dat10"));
        splitter->addWidget(label_dat10);
        label_w = new QLabel(centralWidget);
        label_w->setObjectName(QStringLiteral("label_w"));
        label_w->setGeometry(QRect(0, 90, 71, 41));
        label_h = new QLabel(centralWidget);
        label_h->setObjectName(QStringLiteral("label_h"));
        label_h->setGeometry(QRect(0, 40, 71, 41));
        MainWindow->setCentralWidget(centralWidget);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", 0));
        pushButton->setText(QApplication::translate("MainWindow", "Test", 0));
        comboBox->clear();
        comboBox->insertItems(0, QStringList()
         << QApplication::translate("MainWindow", "1cm", 0)
         << QApplication::translate("MainWindow", "1dm", 0)
         << QApplication::translate("MainWindow", "1m", 0)
        );
        label->setText(QApplication::translate("MainWindow", "Range:", 0));
        pushButton_2->setText(QApplication::translate("MainWindow", "Show Dat", 0));
        label_static1->setText(QApplication::translate("MainWindow", "10", 0));
        label_static2->setText(QApplication::translate("MainWindow", "50", 0));
        label_static3->setText(QApplication::translate("MainWindow", "100", 0));
        label_static4->setText(QApplication::translate("MainWindow", "500", 0));
        label_static5->setText(QApplication::translate("MainWindow", "1000", 0));
        label_static6->setText(QApplication::translate("MainWindow", "5000", 0));
        label_static7->setText(QApplication::translate("MainWindow", "10000", 0));
        label_dat1->setText(QApplication::translate("MainWindow", "1.", 0));
        label_dat2->setText(QApplication::translate("MainWindow", "2.", 0));
        label_dat3->setText(QApplication::translate("MainWindow", "3.", 0));
        label_dat4->setText(QApplication::translate("MainWindow", "4.", 0));
        label_dat5->setText(QApplication::translate("MainWindow", "5.", 0));
        label_dat6->setText(QApplication::translate("MainWindow", "6.", 0));
        label_dat7->setText(QApplication::translate("MainWindow", "7.", 0));
        label_dat8->setText(QApplication::translate("MainWindow", "8.", 0));
        label_dat9->setText(QApplication::translate("MainWindow", "9.", 0));
        label_dat10->setText(QApplication::translate("MainWindow", "10.", 0));
        label_w->setText(QApplication::translate("MainWindow", "MIn_h:", 0));
        label_h->setText(QApplication::translate("MainWindow", "Min_w:", 0));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
