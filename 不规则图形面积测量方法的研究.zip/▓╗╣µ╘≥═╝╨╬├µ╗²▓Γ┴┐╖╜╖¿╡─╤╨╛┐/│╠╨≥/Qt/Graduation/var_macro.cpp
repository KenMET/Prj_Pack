#include "var_macro.h"


mpu_var::mpu_var()
{
    q0=1.0f;
    q1=0.0f;
    q2=0.0f;
    q3=0.0f;

    pitch=0.0f;
    roll=0.0f;
    yaw=0.0f;
}

encoder_var::encoder_var()
{
    pause = 0;
    rand = 0;

    distance = 0;
}
















