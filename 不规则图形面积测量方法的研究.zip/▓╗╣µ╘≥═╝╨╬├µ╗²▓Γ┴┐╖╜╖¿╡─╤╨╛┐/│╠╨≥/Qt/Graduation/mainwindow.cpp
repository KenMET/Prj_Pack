#include "mainwindow.h"
#include "ui_mainwindow.h"

#include <qmessagebox.h>
#include <qpainter.h>
#include <qrect.h>
#include <qbrush.h>
#include <qfont.h>
#include <qfile.h>
#include <qtimer.h>
#include <qscreen.h>
#include <qimage.h>
#include <qpixmap.h>
#include <qrgb.h>
#include <QtCore>


bool start_measure=0;

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    //testTimer = new QTimer(this);
    //connect( testTimer, SIGNAL(timeout()), this, SLOT(TimerFunc()) );
    //testTimer->start(1000);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::paintEvent(QPaintEvent *event)
{
    User_Init();
    switch(paint_cmd)
    {
    case 1:
        Put_Canvas2Screen();
        break;
    case 2:
        Put_Canvas2Screen();
        //Fill_Canvas();
        break;
    case 3:
        Caculation_Canvas();
        break;
    case 4:
        ui->pushButton_2->setText("Loading");
        paint_cmd = 3;
        this->update();
        return;
    }
    paint_cmd = 0;
}

void MainWindow::TimerFunc()
{
    static int test = 0;

    printf("start:%d\n", test);

    vectors vectors_test[15]={
            {45, 30},
            {135, 30},
            {225, 30},
            {315, 30},
    };

    if(test == 0)
        Put_Vector2Canvas(vectors_test, 2, 1);
    else if(test == 1)
        Put_Vector2Canvas(&vectors_test[2], 1, 0);

    if(test++ == 2)
    {
        ui->pushButton->setText("Start M");

        vectors_count = 0;
        start_measure = 0;

        show_able = 1;
        ui->pushButton_2->setVisible(1);\
        testTimer->stop();

        paint_cmd = 2;
        this->update();
        test = 0;
        return ;
    }



    //Put_Canvas2File();

    paint_cmd = 1;
    this->update();
}

/*
void MainWindow::Put_Canvas2File(void)
{
    QFile file("Canvas.cav");
    if(!file.open(QIODevice::ReadWrite))
    {
        MSG_BOX("Open Err");
    }

    QString content = "canvas value:\n";
    QString Add;

    for(int i=record.left-1; i<=record.right; i++)
    {
        for(int j=record.bottom; j<=record.top; j++)
        {
            Add.sprintf("%d",canvas[i][j]);
            content += Add;
        }
        Add.sprintf("\n");
        content += Add;
    }


    int length = file.write(content.toLatin1(),content.length());
    if(length == -1)
    {
        MSG_BOX("write Err");
    }
    else
    {
        //MSG_BOX("write OK len:%d", length);
    }
}
*/


void MainWindow::Put_Canvas2Screen(void)
{
    QPainter painter(this);
    QPen pen;

    pen.setColor(Qt::black);
    pen.setWidth(1);
    painter.setPen(pen);

    float wight_bili, hight_bili, zuijia_bili;
    hight_bili = (float)(record.top - record.bottom + RESERVE) / (float)PAINTER_HEIGHT;
    wight_bili = (float)(record.right - record.left + RESERVE) / (float)PAINTER_WIDTH;
    if(hight_bili > wight_bili)
        zuijia_bili = hight_bili;
    else
        zuijia_bili = wight_bili;

    int test_x, test_y;

    for(int j=0; j<record.count; j++)
    {
        test_x = record.pos_x[j] - record.left + RESERVE / 2;
        test_y = record.pos_y[j] - record.bottom + RESERVE / 2;
        test_x = test_x / zuijia_bili;
        test_y = test_y / zuijia_bili;
        pionts[j] = QPointF(test_x + PAINTER_FOR_MENU, test_y);
    }

    painter.setBrush(QBrush(Qt::blue, Qt::SolidPattern));
    painter.drawPolygon(pionts, record.count);

    pen.setColor(Qt::blue);
    painter.setPen(pen);

    test_x = record.pos_x[0] - record.left + RESERVE / 2;
    test_y = record.pos_y[0] - record.bottom + RESERVE / 2;
    test_x = test_x / zuijia_bili;
    test_y = test_y / zuijia_bili;
    pionts[0] = QPointF(test_x + PAINTER_FOR_MENU, test_y);

    test_x = record.pos_x[record.count-1] - record.left + RESERVE / 2;
    test_y = record.pos_y[record.count-1] - record.bottom + RESERVE / 2;
    test_x = test_x / zuijia_bili;
    test_y = test_y / zuijia_bili;
    pionts[1] = QPointF(test_x + PAINTER_FOR_MENU, test_y);

    painter.drawLine(pionts[0], pionts[1]);


}

/*
void MainWindow::Fill_Canvas(void)
{
    printf("Start Conect Start and End_Points:");
    Conect_StartEnd_Point(BUFF_WIDTH / 2, BUFF_HEIGHT / 2, record.pos_x[record.count-1], record.pos_y[record.count-1]);
    printf("OK\n");


    printf("Start fill hole:");

    for(int j = record.bottom - 2; j < record.top + 2; j++)
    {
        for(int i = record.left - 2; i < record.right + 2; i++)
        {
            if(canvas[i][j] == 0)
            {
                canvas[i][j] = 1;
            }
            else if(canvas[i][j] == 1)
            {
                break;
            }
        }
    }

    for(int j = record.bottom - 2; j < record.top + 2; j++)
    {
        for(int i = record.right + 2; i > record.left - 2; i--)
        {
            if(canvas[i][j] == 0)
            {
                canvas[i][j] = 1;
            }
            else if(canvas[i][j] == 1)
            {
                break;
            }
        }
    }

    printf("OK\n");

    //printf("Start put Canvas to file:");
    //Put_Canvas2File();
   // printf("OK\n");

    printf("Canvas hole fill OK, you can push button show data now\n");

}
*/


void MainWindow::Caculation_Canvas(void)
{
    QString content;
    QString Add;
    const int caculat_list[7]={10, 50 , 100, 500, 1000, 5000, 10000};

    int drop_point_x = 0, drop_point_y = 0;
    int rect_w = record.right - record.left;
    int rect_h = record.top - record.bottom + 1;

    //printf("rect_w:%d rect_h:%d\n", rect_w, rect_h);
/*
    float test1, test2;
    test1 = rect_w;
    test2 = rect_h;
    test1 *= test2;
    test2 = canvas_1_count-1;

    test1 = test2 / test1;
*/


    int right,left,top,bottom;
    QImage *img=new QImage;
    if(!img->load("Screen.jpg"))
    {
        printf("lode screen Faile\n");
    }


    for(int w=0; w<img->width(); w++)
    {
        for(int h=0; h<img->height(); h++)
        {
            if((img->pixel(QPoint(w,h)) & 0xffffff) <= 0xff && (img->pixel(QPoint(w,h)) & 0xffffff) > 0xfd)
                right = w-3;
        }
    }

    for(int w=img->width()-1; w>=0; w--)
    {
        for(int h=0; h<img->height(); h++)
        {
            if((img->pixel(QPoint(w,h)) & 0xffffff) <= 0xff && (img->pixel(QPoint(w,h)) & 0xffffff) > 0xfd)
                left = w+3;
        }
    }

    for(int h=0; h<img->height(); h++)
    {
        for(int w=0; w<img->width(); w++)
        {
            if((img->pixel(QPoint(w,h)) & 0xffffff) <= 0xff && (img->pixel(QPoint(w,h)) & 0xffffff) > 0xfd)
                top = h-3;
        }
    }

    for(int h=img->height()-1; h>=0; h--)
    {
        for(int w=0; w<img->width(); w++)
        {
            if((img->pixel(QPoint(w,h)) & 0xffffff) <= 0xff && (img->pixel(QPoint(w,h)) & 0xffffff) > 0xfd)
                bottom = h+3;
        }
    }

    rect_w = right - left;
    rect_h = top - bottom;
    printf("rect_w:%d rect_h:%d\n", rect_w, rect_h);

    ui->label_h->setVisible(0);
    ui->label_w->setVisible(0);
    ui->label_dat1->setVisible(1);
    ui->label_dat2->setVisible(1);
    ui->label_dat3->setVisible(1);
    ui->label_dat4->setVisible(1);
    ui->label_dat5->setVisible(1);
    ui->label_dat6->setVisible(1);
    ui->label_dat7->setVisible(1);
    ui->label_dat8->setVisible(1);
    ui->label_dat9->setVisible(1);
    ui->label_dat10->setVisible(1);

    ui->label_static1->setVisible(1);
    ui->label_static2->setVisible(1);
    ui->label_static3->setVisible(1);
    ui->label_static4->setVisible(1);
    ui->label_static5->setVisible(1);
    ui->label_static6->setVisible(1);
    ui->label_static7->setVisible(1);

    int in_count = 0;
    int rand_num = 3;
    int k=0;

    QTime current_time;
    for(int i=0; i < 10; i++)
    {
        printf("Now caculat:%d\n", i);
        content.sprintf("%d.", i);
        for(k=0; k < 7; k++)
        {
            for(int count=0; count<caculat_list[k]; count++)
            {
                qsrand(rand_num);
                current_time = QTime::currentTime();
                rand_num = qrand() + current_time.msec();
                //drop_point_x = rand_num % rect_w + record.left;
                drop_point_x = rand_num % rect_w + left;

                qsrand(rand_num);
                rand_num = qrand() + current_time.msec();
                //drop_point_y = rand_num % rect_h + record.bottom;
                drop_point_y = rand_num % rect_h + bottom;

                //if(canvas[drop_point_x][drop_point_y] == 0)
                //    in_count ++;

                if((img->pixel(QPoint(drop_point_x,drop_point_y)) & 0xffffff) <= 0xff && (img->pixel(QPoint(drop_point_x,drop_point_y)) & 0xffffff) > 0xfd)
                    in_count ++;
            }
            //in_count += test1 * caculat_list[k];
            if(k == 0 || k >= 4)
                Add.sprintf("    %d", in_count);
            else
                Add.sprintf("     %d", in_count);
            content += Add;
            in_count = 0;
        }
        switch(i)
        {
            case 0: ui->label_dat1->setText(content);  break;
            case 1: ui->label_dat2->setText(content);  break;
            case 2: ui->label_dat3->setText(content);  break;
            case 3: ui->label_dat4->setText(content);  break;
            case 4: ui->label_dat5->setText(content);  break;
            case 5: ui->label_dat6->setText(content);  break;
            case 6: ui->label_dat7->setText(content);  break;
            case 7: ui->label_dat8->setText(content);  break;
            case 8: ui->label_dat9->setText(content);  break;
            case 9: ui->label_dat10->setText(content);  break;
        }
    }
    QScreen *screen = QGuiApplication::primaryScreen();
    if(!screen->grabWindow(0).save("Data.jpg", "jpg"))
    {
        printf("cat Data Faile\n");
    }
    delete img;
    ui->pushButton_2->setText("Show Dat");
}

void MainWindow::User_Init(void)
{
    QPainter painter(this);

    QPen pen;

    if(!show_able)
    {

        ui->label_dat1->setVisible(0);
        ui->label_dat2->setVisible(0);
        ui->label_dat3->setVisible(0);
        ui->label_dat4->setVisible(0);
        ui->label_dat5->setVisible(0);
        ui->label_dat6->setVisible(0);
        ui->label_dat7->setVisible(0);
        ui->label_dat8->setVisible(0);
        ui->label_dat9->setVisible(0);
        ui->label_dat10->setVisible(0);

        ui->label_static1->setVisible(0);
        ui->label_static2->setVisible(0);
        ui->label_static3->setVisible(0);
        ui->label_static4->setVisible(0);
        ui->label_static5->setVisible(0);
        ui->label_static6->setVisible(0);
        ui->label_static7->setVisible(0);

        ui->pushButton_2->setVisible(0);
    }

    pen.setColor(Qt::red);
    pen.setWidth(2);
    painter.setPen(pen);
    painter.setBrush(Qt::white);
    painter.drawRect(PAINTER_START_X, PAINTER_START_Y, PAINTER_END_X, PAINTER_END_Y);

}


void MainWindow::main_ThreadSlot(mpu_var *mpu)
{
    if(mpu == NULL)
    {
        printf("main_ThreadSlot : mpu == NULL\n");
        return ;
    }
    //printf("P:%f   R:%f   Y:%f\n", mpu->pitch, mpu->roll, mpu->yaw);
    if(mpu->yaw > -180.0f && mpu->yaw < 180.0f)
        angle_arr[angle_count++] = mpu->yaw + 180.0f;
}

void MainWindow::main_ThreadSlot(encoder_var *encode)
{
    if(encode == NULL)
    {
        printf("main_ThreadSlot : encode == NULL\n");
        return ;
    }

    double angle_avg = 0;
    double avg_time = angle_count;

    for(int k=0; k<angle_count; k++)
        angle_avg += angle_arr[k];
    angle_avg /= avg_time;
    angle_count = 0;

    if(last_pause == 0)
    {
        last_pause = encode->pause;
        return ;
    }
    int pause = encode->pause - last_pause;
    last_pause = encode->pause;

    if(abs(pause) < 100 || abs(pause) > 10000)
    {
        return ;
    }

    float rand = pause;

    if(rand < 0)
    {
        rand = -rand;
        angle_avg += 180.0f;
        if(angle_avg > 360.0f)
            angle_avg -= 360.0f;
    }

    rand /= 1000.0f;
    float distance = PERIMETER * rand;
    distance /= 10.0f;

    vectors_origin[vectors_count].angle = angle_avg;
    vectors_origin[vectors_count].distance = distance;
    vectors_count++;

    vectors vec_single;
    vec_single.angle = angle_avg;
    vec_single.distance = distance;

    if(vectors_count == 1)
        Put_Vector2Canvas(&vec_single, 1, 1);
    else
        Put_Vector2Canvas(&vec_single, 1, 0);
    //else if(vectors_count == 100)
    //    Put_Vector2Canvas(&vec_single, 1, 2);



    paint_cmd = 1;
    this->update();

    //printf("pause:%d distance:%fcm angle:%f count:%d\n", encode->pause, distance, angle_avg, vectors_count);
}


