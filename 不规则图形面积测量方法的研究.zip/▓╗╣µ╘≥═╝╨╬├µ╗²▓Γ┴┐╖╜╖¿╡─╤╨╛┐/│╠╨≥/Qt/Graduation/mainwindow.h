#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QThread>

#include "var_macro.h"

#include "mpu_thread.h"
#include "encoder_thread.h"

extern bool start_measure;

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

private:
    Ui::MainWindow *ui;
    mpu_thread *mpu_Thrd;
    encoder_thread *encode_Thrd;

public:
    struct vectors{
        float angle;
        float distance;
    };
    struct record_point{\
        int count;
        int left;
        int right;
        int top;
        int bottom;
        int pos_x[BUFF_WIDTH];
        int pos_y[BUFF_HEIGHT];
    };

    float angle_arr[BUFF_WIDTH];
    int angle_count;
    int last_pause;
    vectors vectors_origin[BUFF_WIDTH];
    int vectors_count;
    bool show_able;

    record_point record;
    /*
    bool canvas[BUFF_WIDTH][BUFF_HEIGHT];
    int canvas_1_count;
    */

    int paint_cmd;

    void paintEvent(QPaintEvent *event);


    void User_Init(void);

    void Put_Canvas2File(void);
    void Put_Vector2Canvas(vectors *vector, int count, int is_new_paint_or_end);
    void Put_Canvas2Screen(void);
    void Conect_StartEnd_Point(int startX, int startY, int endX, int endY);
    void Fill_Canvas(void);
    void Caculation_Canvas(void);

    QTimer *testTimer;
    QPointF pionts[1000];


    int mpu6050_open(const char *path);
    int mpu6050_process(void);
    int mpu6050_create_thread(void);

private slots:
    void on_pushButton_clicked();

    void TimerFunc();



//Thread:
    void main_ThreadSlot(encoder_var*);
    void main_ThreadSlot(mpu_var*);

    void on_pushButton_2_clicked();
};

#endif // MAINWINDOW_H
