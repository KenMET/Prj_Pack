#ifndef VAR_MACRO_H
#define VAR_MACRO_H

#include <QMainWindow>

#define PAINTER_FOR_MENU    82

#define PAINTER_WIDTH       (width() - PAINTER_FOR_MENU)
#define PAINTER_HEIGHT      height()

#define PAINTER_START_X     PAINTER_FOR_MENU
#define PAINTER_START_Y     0
#define PAINTER_END_X       width()
#define PAINTER_END_Y       height()

#define BUFF_WIDTH          2000
#define BUFF_HEIGHT         2000

#define RESERVE             2

#define BUFF1_SIZE          3

#define MSG_BOX(...)        do{char test[50];sprintf(test, ##__VA_ARGS__);QMessageBox::information(NULL, "Debug", test);}while(0)


class mpu_var{
public:
    mpu_var();

    double q0;
    double q1;
    double q2;
    double q3;

    double pitch;
    double roll;
    double yaw;
};

class encoder_var{
public:
    encoder_var();

    int pause;
    int rand;

    int distance;
};

#endif // VAR_MACRO_H
