#include "mainwindow.h"
#include "ui_mainwindow.h"

#include <qmessagebox.h>
#include <qpainter.h>
#include <qrect.h>
#include <qbrush.h>
#include <qfont.h>
#include <qrect.h>
#include <qfile.h>
#include <qtimer.h>
#include <qscreen.h>
#include <qimage.h>
#include <qpixmap.h>
#include <qrgb.h>
#include <QtCore>

#include "mpu_thread.h"
#include "encoder_thread.h"

void MainWindow::on_pushButton_clicked()
{
    printf("Button1\n");
    if(!start_measure)
    {
        ui->pushButton_2->setVisible(0);\
        show_able = 0;
        start_measure = 1;

        this->update();

        mpu_Thrd = new mpu_thread;
        encode_Thrd = new encoder_thread;

        connect(mpu_Thrd, SIGNAL(mpu_ThreadSignal(mpu_var*)), this, SLOT(main_ThreadSlot(mpu_var*)));
        connect(encode_Thrd, SIGNAL(encoder_ThreadSignal(encoder_var*)), this, SLOT(main_ThreadSlot(encoder_var*)));

        mpu_Thrd->start();
        encode_Thrd->start();

        ui->pushButton->setText("Stop M");
    }
    else
    {
        mpu_Thrd->quit();
        encode_Thrd->quit();

        ui->pushButton->setText("Start M");
        printf("Thrd have stoped!\n");

        QScreen *screen = QGuiApplication::primaryScreen();
        if(!screen->grabWindow(0).save("Screen.jpg", "jpg"))
        {
            printf("cat screen Faile\n");
        }

        vectors_count = 0;
        start_measure = 0;

        show_able = 1;
        ui->pushButton_2->setVisible(1);\

        paint_cmd = 2;
        this->update();


    }
}


void MainWindow::on_pushButton_2_clicked()
{
    //ui->pushButton_2->setVisible(0);
    paint_cmd = 4;
    this->update();
}




void MainWindow::Put_Vector2Canvas(vectors *vector, int count, int is_new_paint_or_end)
{
    //int canvas_w, canvas_h;
    static int last_canvas_w = BUFF_WIDTH / 2, last_canvas_h = BUFF_HEIGHT / 2;
    //int caiji_count;
    //float xielv;
    float chang, kuan;
    //bool scan_way = 0;

    if(is_new_paint_or_end == 1)
    {
        //for(int j=record.left; j<record.right; j++)
        //{
        //    memset(&canvas[j][record.bottom], 0, record.top - record.bottom);
        //}
        ui->label_h->setVisible(1);
        ui->label_w->setVisible(1);
        record.count = 0;
        //canvas_1_count = 0;
        last_canvas_w = BUFF_WIDTH / 2;
        last_canvas_h = BUFF_HEIGHT / 2;
        record.left = last_canvas_w;
        record.right = last_canvas_w;
        record.top = last_canvas_h;
        record.bottom = last_canvas_h;
        record.pos_x[record.count] = last_canvas_w;
        record.pos_y[record.count] = last_canvas_h;
        record.count++;
        //canvas_1_count++;
    }
    else
    {
        last_canvas_w = record.pos_x[record.count - 1];
        last_canvas_h = record.pos_y[record.count - 1];
    }


    float angle, distance;

    for(int k=1; k<=count; k++)
    {
        angle = vector[k-1].angle;
        distance = vector[k-1].distance;


        chang = cos((M_PI * angle) / 180) * distance;
        kuan =  sin((M_PI * angle) / 180) * distance;
/*
        if(abs(kuan) > abs(chang))
        {
            if(kuan > 0)
                caiji_count = (int)(kuan + 0.5);
            else
                caiji_count = (int)(kuan - 0.5);
            xielv = chang / kuan;
            scan_way = 1;   //shu zhi sao miao
        }
        else
        {
            if(chang > 0)
                caiji_count = (int)(chang + 0.5);
            else
                caiji_count = (int)(chang - 0.5);
            xielv = kuan / chang;
            scan_way = 0;   //shui ping sao miao
        }
        //MSG_BOX("caiji_count:%d", caiji_count);
        if(scan_way)
        {
            if(caiji_count > 0)
            {
                for(int j=0; j<=caiji_count; j++)
                {
                    canvas_h = j;
                    canvas_w = j * xielv + 0.5;
                    canvas[canvas_w + last_canvas_w][canvas_h + last_canvas_h] = 1;
                    canvas_1_count++;
                    //MSG_BOX("CANVAS_X:%d CANVAS_Y:%d", canvas_w + last_canvas_w, canvas_h + last_canvas_h);
                }
            }
            else
            {
                for(int j=0; j>=caiji_count; j--)
                {
                    canvas_h = j;
                    canvas_w = j * xielv - 0.5;
                    canvas[canvas_w + last_canvas_w][canvas_h + last_canvas_h] = 1;
                    canvas_1_count++;
                    //MSG_BOX("CANVAS_X:%d CANVAS_Y:%d", canvas_w + last_canvas_w, canvas_h + last_canvas_h);
                }
            }
        }
        else
        {
            if(caiji_count > 0)
            {
                for(int j=0; j<=caiji_count; j++)
                {
                    canvas_w = j;
                    canvas_h = j * xielv + 0.5;
                    canvas[canvas_w + last_canvas_w][canvas_h + last_canvas_h] = 1;
                    canvas_1_count++;
                    //MSG_BOX("CANVAS_X:%d CANVAS_Y:%d", canvas_w + last_canvas_w, canvas_h + last_canvas_h);
                }
            }
            else
            {
                for(int j=0; j>=caiji_count; j--)
                {
                    canvas_w = j;
                    canvas_h = j * xielv - 0.5;
                    canvas[canvas_w + last_canvas_w][canvas_h + last_canvas_h] = 1;
                    canvas_1_count++;
                    //MSG_BOX("CANVAS_X:%d CANVAS_Y:%d", canvas_w + last_canvas_w, canvas_h + last_canvas_h);
                }
            }
        }
*/

        if(chang > 0)
            last_canvas_w += (int)(chang + 0.5);
        else
            last_canvas_w += (int)(chang - 0.5);
        if(kuan > 0)
            last_canvas_h += (int)(kuan + 0.5);
        else
            last_canvas_h += (int)(kuan - 0.5);


        record.pos_x[record.count] = last_canvas_w;
        record.pos_y[record.count] = last_canvas_h;
        record.count++;

        printf("distance:%fcm angle:%f count:%d recoder_w:%d recoder_h:%d\n", distance, angle, vectors_count, last_canvas_w, last_canvas_h);

        if(last_canvas_w < record.left)
            record.left = last_canvas_w;
        if(last_canvas_w > record.right)
            record.right = last_canvas_w;
        if(last_canvas_h < record.bottom)
            record.bottom = last_canvas_h;
        if(last_canvas_h > record.top)
            record.top = last_canvas_h;
        QString content;
        content.sprintf("Min_w:\n%d", record.right - record.left);
        ui->label_w->setText(content);
        content.sprintf("Min_h:\n%d", record.top - record.bottom + 1);
        ui->label_h->setText(content);
    }
    //if(is_new_paint_or_end == 2)
    //   Conect_StartEnd_Point(BUFF_WIDTH / 2, BUFF_HEIGHT / 2, last_canvas_w, last_canvas_h);
}

/*
void MainWindow::Conect_StartEnd_Point(int startX, int startY, int endX, int endY)
{
    float chang, kuan;
    float xielv;
    bool scan_way = 0;
    int caiji_count;
    int canvas_w, canvas_h;

    if(endX != startX || endY != startY)
    {
        chang = startX - endX;
        kuan  = startY - endY;
        if(abs(chang) > abs(kuan))
        {
            caiji_count = startX - endX;
            xielv = kuan / chang;
            scan_way = 0;   //shui ping sao miao
        }
        else
        {
            caiji_count = startY - endY;
            xielv = chang / kuan;
            scan_way = 1;   //shu zhi sao miao
        }
        if(caiji_count > 0)
        {
            for(int j=0; j<caiji_count; j++)
            {
                if(scan_way == 0)
                {
                    canvas_w = j;
                    canvas_h = j * xielv - 0.5;
                }
                else
                {
                    canvas_h = j;
                    canvas_w = j * xielv - 0.5;
                }
                canvas[canvas_w + endX][canvas_h + endY] = 1;
                canvas_1_count++;
            }
        }
        else
        {
            for(int j=0; j>caiji_count; j--)
            {
                if(scan_way == 0)
                {
                    canvas_w = j;
                    canvas_h = j * xielv - 0.5;
                }
                else
                {
                    canvas_h = j;
                    canvas_w = j * xielv - 0.5;
                }
                canvas[canvas_w + endX][canvas_h + endY] = 1;
                canvas_1_count++;
            }
        }
    }
}
*/






