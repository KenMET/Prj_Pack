#ifndef MPU_THREAD_H
#define MPU_THREAD_H

#include <QThread>

#include "var_macro.h"

#define RAD_TO_DEG  57.295779513082320876798154814105f
#define DEG_TO_RAD  0.01745329251994329576923690768489f
#define q30         1073741824.0f


#define mpu6050_dev    "/dev/input/event1"


#define MAX_EVENTS 10




class mpu_thread : public QThread
{
    Q_OBJECT
public:

    mpu_thread();
    int mpu6050_open(const char *path);

signals:
    void mpu_ThreadSignal(mpu_var*);

public slots:
    void mpu_ThreadSlot(const int);
protected:
    void run() override;

public:

};

#endif // MPU_THREAD_H
