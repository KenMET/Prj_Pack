#include "encoder_thread.h"

#include "mainwindow.h"

#include <fcntl.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/epoll.h>

#include <linux/input.h>

#include <string.h>
#include <math.h>

#define encoder_dev    "/dev/input/event2"

#define MAX_EVENTS 10

struct epoll_event en_encoder;
struct epoll_event events_encoder[MAX_EVENTS];
char buffer_encoder[sizeof(input_event)];

encoder_thread::encoder_thread()
{

}

int encoder_thread::encoder_open(const char *path)
{
    return open(path, O_RDONLY | O_NONBLOCK);
}


void encoder_thread::run(void)
{
    printf("encoder_thread run\n");

    int e_fd = epoll_create(1);
    if (e_fd == -1){
        printf("epoll create fail!\n");
    }

    int fd= encoder_open(encoder_dev);
    if(fd < 0){
        printf("encoder open err");
        exec();
        //return fd_dev1;
    }

    en_encoder.data.fd = fd;
    en_encoder.events = EPOLLIN | EPOLLET;
    int e_ctl = epoll_ctl(e_fd, EPOLL_CTL_ADD, fd, &en_encoder);

    if (e_ctl < 0){
        printf("add encoder device in epoll fail!\n");
        exec();
        //return e_ctl;
    }

    int re;
    encoder_var var;
    while(1){
        re = epoll_wait(e_fd, events_encoder, MAX_EVENTS, -1);
        for (int i = 0; i < re; ++i) {
            if (events_encoder[i].events & EPOLLIN) {

                ssize_t resize = 0;
                ssize_t n = 0;
                struct input_event input_ev;
                while ((resize = read(en_encoder.data.fd, buffer_encoder + n, sizeof(struct input_event) - n)) > 0) {
                    n += resize;
                    if (n == sizeof(input_event)) {
                        memcpy((void*)(&input_ev), buffer_encoder, sizeof(input_event));

                        if(input_ev.type == 3 && input_ev.code == 0)
                            var.pause = input_ev.value;
                        else if(input_ev.type == 3 && input_ev.code == 1)
                            var.rand = input_ev.value;
                        else if(input_ev.type == 1)
                        {
                            //printf("pause:%d rand:%d\n", pause, rand);
                            if(start_measure)
                                emit encoder_ThreadSignal(&var);
                        }

                        n = 0;
                    }
                }
            }
        }

    }


    exec();
    //return 0;
}

void encoder_thread::encoder_ThreadSlot(const int val)
{
    printf("encoder_ThreadSlot:%d\n", val);
}
