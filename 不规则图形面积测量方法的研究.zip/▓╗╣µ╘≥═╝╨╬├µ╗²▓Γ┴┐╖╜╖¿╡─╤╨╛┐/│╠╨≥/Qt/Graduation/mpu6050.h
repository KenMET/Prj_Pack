#ifndef MPU6050_H
#define MPU6050_H

#include <QMainWindow>
#include <QObject>
#include <QSharedDataPointer>
#include <QWidget>

class mpu6050Data;

class mpu6050 : public QMainWindow
{
    Q_OBJECT
public:
    explicit mpu6050(QWidget *parent = 0);
    mpu6050(const mpu6050 &);
    mpu6050 &operator=(const mpu6050 &);
    ~mpu6050();

signals:

public slots:

private:
    QSharedDataPointer<mpu6050Data> data;
};

#endif // MPU6050_H