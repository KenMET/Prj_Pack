#ifndef ENCODER_THREAD_H
#define ENCODER_THREAD_H

#include <QMainWindow>
#include <QObject>
#include <QWidget>
#include <QThread>

#include "var_macro.h"


#define PERIMETER           300.0f //mm


class encoder_thread : public QThread
{
    Q_OBJECT
public:
    encoder_thread();
    int encoder_open(const char *path);

signals:
    void encoder_ThreadSignal(encoder_var*);

public slots:
    void encoder_ThreadSlot(const int);
protected:
    void run() override;

};

#endif // ENCODER_THREAD_H
