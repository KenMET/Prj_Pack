#include "mpu_thread.h"

#include "mainwindow.h"

#include <fcntl.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/epoll.h>

#include <linux/input.h>

#include <string.h>
#include <math.h>

#include "var_macro.h"


struct epoll_event ev;
struct epoll_event events[MAX_EVENTS];
char buffer[sizeof(input_event)];


mpu_thread::mpu_thread()
{

}


int mpu_thread::mpu6050_open(const char *path)
{
    return open(path, O_RDONLY | O_NONBLOCK);
}


void mpu_thread::run(void)
{
    printf("mpu_thread run\n");

    int e_fd = epoll_create(1);
    if (e_fd == -1){
        printf("epoll create fail!\n");
    }

    int fd_dev1 = mpu6050_open(mpu6050_dev);
    if(fd_dev1 < 0){
        printf("mpu6050_dev open err");
        exec();
        //return fd_dev1;
    }

    ev.data.fd = fd_dev1;
    ev.events = EPOLLIN | EPOLLET;
    int e_ctl = epoll_ctl(e_fd, EPOLL_CTL_ADD, fd_dev1, &ev);

    if (e_ctl < 0){
        printf("add mpu device in epoll fail!\n");
        exec();
        //return e_ctl;
    }

    int re;
    mpu_var var;
    while(1){
        re = epoll_wait(e_fd, events, MAX_EVENTS, -1);
        for (int i = 0; i < re; ++i) {
            if (events[i].events & EPOLLIN) {

                ssize_t resize = 0;
                ssize_t n = 0;
                struct input_event input_ev;
                while ((resize = read(ev.data.fd, buffer + n, sizeof(struct input_event) - n)) > 0) {
                    n += resize;
                    if (n == sizeof(input_event)) {
                        memcpy((void*)(&input_ev), buffer, sizeof(input_event));

                        if(input_ev.type == 3)
                        {
                            switch(input_ev.code)
                            {
                                case 0: var.q0 = input_ev.value;    var.q0 /= q30;  break;
                                case 1: var.q1 = input_ev.value;    var.q1 /= q30;  break;
                                case 2: var.q2 = input_ev.value;    var.q2 /= q30;  break;
                                case 3: var.q3 = input_ev.value;    var.q3 /= q30;  break;
                                default :   printf("err code\n");           break;
                            }
                        }
                        else if(input_ev.type == 1)
                        {
                            var.pitch = asin(2 * var.q1 * var.q3 - 2 * var.q0 * var.q2)* RAD_TO_DEG;
                            var.roll  = -atan2( -2 * var.q1 * var.q1 - 2 * var.q2 * var.q2 + 1,2 * var.q2 * var.q3 + 2 * var.q0 * var.q1)* RAD_TO_DEG;
                            var.yaw   = atan2(2*(var.q1*var.q2 + var.q0*var.q3),var.q0*var.q0+var.q1*var.q1-var.q2*var.q2-var.q3*var.q3) * RAD_TO_DEG;
                            //printf("P:%f   R:%f   Y:%f\n", var.pitch, var.roll, var.yaw);
                            if(start_measure)
                                emit mpu_ThreadSignal(&var);
                        }
                        n = 0;
                    }
                }
            }
        }

    }


    exec();
    //return 0;
}

void mpu_thread::mpu_ThreadSlot(const int val)
{
    printf("mpu_ThreadSlot:%d\n", val);
}






