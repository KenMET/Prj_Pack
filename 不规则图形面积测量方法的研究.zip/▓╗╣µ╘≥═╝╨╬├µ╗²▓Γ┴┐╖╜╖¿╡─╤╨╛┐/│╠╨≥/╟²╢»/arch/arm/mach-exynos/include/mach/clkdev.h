#ifndef __MACH_CLKDEV_H__
#define __MACH_CLKDEV_H__

#define __clk_get(clk) ({ 1; })
#define __clk_put(clk) do {} while (0)

#endif
