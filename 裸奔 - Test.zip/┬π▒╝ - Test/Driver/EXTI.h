#ifndef _EXTI_H_
#define _EXTI_H_



#include "stm32f10x.h"
#include "stm32f10x_exti.h"


#include "ov7670.h"


#define GPIO_Pin_OV7670	 								GPIO_Pin_7
#define GPIO_PinSourceEXTI_OV7670 			GPIO_PinSource7
#define EXTI_LINE_OV7670 								EXTI_Line7
#define EXTI_IRQ_OV7670 	  						EXTI9_5_IRQn

#define GPIO_PortSourceEXTI_OV7670 			GPIO_PortSourceGPIOA
#define GPIO_Port_OV7670  							GPIOA



extern void My_EXTI_Init(void);


#endif
