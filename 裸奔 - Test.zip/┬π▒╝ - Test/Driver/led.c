#include "led.h"
/****************************************************************************
* Function Name  : LED_Init
* Description    : Configures the used GPIO of LED .
* Input          : None
* Output         : None
* Return         : None
****************************************************************************/

void LED_Init(void)
{

	GPIO_InitTypeDef GPIO_InitStructure_LED;
	RCC_APB2PeriphClockCmd(RCC_LED0|RCC_LED1, ENABLE);
	
	GPIO_InitStructure_LED.GPIO_Pin = PIN_LED1;			 //����LED��� D2
  	GPIO_InitStructure_LED.GPIO_Mode = GPIO_Mode_Out_PP;
  	GPIO_InitStructure_LED.GPIO_Speed = GPIO_Speed_50MHz;
  	GPIO_Init(GPIO_LED1, &GPIO_InitStructure_LED);

	GPIO_InitStructure_LED.GPIO_Pin = PIN_LED0;			 //����LED��� D5
  	GPIO_InitStructure_LED.GPIO_Mode = GPIO_Mode_Out_PP;
  	GPIO_InitStructure_LED.GPIO_Speed = GPIO_Speed_50MHz;
  	GPIO_Init(GPIO_LED0, &GPIO_InitStructure_LED);
}

void LED0_Ctrl(unsigned char a) 
{
	if(a)
		GPIO_WriteBit(GPIO_LED0, PIN_LED0, Bit_SET);
	else 
		GPIO_WriteBit(GPIO_LED0, PIN_LED0, Bit_RESET);
}

void LED1_Ctrl(unsigned char a) 
{
	if(a)
		GPIO_WriteBit(GPIO_LED1, PIN_LED1, Bit_SET);
	else 
		GPIO_WriteBit(GPIO_LED1, PIN_LED1, Bit_RESET);
}



