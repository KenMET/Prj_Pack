#include "reg52.h"
#include "intrins.h"

#define Data_8253 P2

sbit WR_8253_U1  = P0^4 ;
sbit CS_8253_U1  = P0^5 ;
sbit A1_U1       = P0^6 ;
sbit A0_U1       = P0^7 ;

sbit WR_8253_U2  = P0^3 ;
sbit CS_8253_U2  = P0^2 ;
sbit A1_U2       = P0^1 ;
sbit A0_U2       = P0^0 ;



bit flag=0,Start=0;
unsigned int ReadData;
unsigned char Caculation;


unsigned char Get_Data[10];


void Delay_ms(unsigned int k)   //��� -0.651041666667us
{
	unsigned char a,b,c;
	for(c=k;c>0;c--)
	    for(b=102;b>0;b--)
	        for(a=3;a>0;a--);
}
void Delay100us(void)   //��� -0.173611111111us
{
    unsigned char a,b;
    for(b=3;b>0;b--)
        for(a=13;a>0;a--);
}

void Time_Init(void)
{
    TMOD = 0x20;
    SCON = 0x50;
    TH1 = 0xFD;
    TL1 = TH1;
    PCON = 0x00;
    EA = 1;
    ES = 1;
    TR1 = 1;
}



void Usart() interrupt 4
{
	ReadData = SBUF;  //SUBF����/���ͻ�����
	RI = 0;		    //���RI�����жϱ�־
	if (ReadData == '@')
		Start = 1;		
	if(Start == 1)
	{
		Get_Data[Caculation++] = ReadData;
		if(ReadData == '~')
		{
			Get_Data[Caculation++] = '\0';
			flag = 1;
			Start = 0;
			Caculation = 0;	
		}	
	}

}

void Cmd_8253(unsigned char cmd,bit A1,bit A0,bit CS)
{
	if(!CS)						   //CS = 0Ϊѡ��һƬ����Ƭ��
	{
		CS_8253_U1 = 1;
		WR_8253_U1 = 0;
		Delay100us();
		Data_8253 = cmd;	
		A1_U1 = A1;A0_U1 = A0;	 
		CS_8253_U1 = 0;	
		Delay100us();
		CS_8253_U1 = 1;	
	}
	else 						   //CS = 1Ϊѡ�ڶ�Ƭ����Ƭ��
	{
		CS_8253_U2 = 1;
		WR_8253_U2 = 0;
		Delay100us();
		Data_8253 = cmd;	
		A1_U2 = A1;A0_U2 = A0;	 
		CS_8253_U2 = 0;	
		Delay100us();
		CS_8253_U2 = 1;	
	}
	Data_8253 = 0x00;
}

void PWM_Ctrl(unsigned char BIT,unsigned char pwm)
{
	switch(BIT)
	{
		case 0 :
		{
			Cmd_8253(pwm,0,1,0);			 					//	��8
			Cmd_8253(0x00,0,1,0);								//  ��8			
		}break;
		case 1 :
		{
			Cmd_8253(pwm,0,0,1);			 					//	��8
			Cmd_8253(0x00,0,0,1);								//  ��8			
		}break;
		case 2 :
		{
			Cmd_8253(pwm,1,0,1);			 					//	��8
			Cmd_8253(0x00,1,0,1);								//  ��8			
		}break;
	}
}

void Init_D8253()
{
	Cmd_8253(0x34,1,1,0);								//U1��ʱ��0�����ڷ�ʽ2

	Cmd_8253(0xff,0,0,0);			 					//	 	 		��8λ
	Cmd_8253(0x00,0,0,0);								//����     		 ��8λ


	Cmd_8253(0x72,1,1,0);								//U1��ʱ��1�����ڷ�ʽ1

	Cmd_8253(0xcf,0,1,0);			 					//��ʼռ�ձ�	��8λ
	Cmd_8253(0x00,0,1,0);								//     		 	��8λ
/////////////////////////////////////////////////////////////////////////////////////////
	Cmd_8253(0xB4,1,1,0);								//U1��ʱ��2�����ڷ�ʽ2

	Cmd_8253(0xff,1,0,0);			 					//����	 	 	��8λ
	Cmd_8253(0x00,1,0,0);								//     		 	��8λ


	Cmd_8253(0x32,1,1,1);								//U2��ʱ��0�����ڷ�ʽ1

	Cmd_8253(0x7f,0,0,1);			 					//��ʼռ�ձ�	��8λ
	Cmd_8253(0x00,0,0,1);								//     		 	��8λ
/////////////////////////////////////////////////////////////////////////////////////////
	Cmd_8253(0x74,1,1,1);								//U2��ʱ��1�����ڷ�ʽ2

	Cmd_8253(0xff,0,1,1);			 					//����	 	 	��8λ
	Cmd_8253(0x00,0,1,1);								//     		 	��8λ


	Cmd_8253(0xb2,1,1,1);								//U2��ʱ��2�����ڷ�ʽ1

	Cmd_8253(0x3f,1,0,1);			 					//��ʼռ�ձ�	��8λ
	Cmd_8253(0x00,1,0,1);								//     		 	��8λ
}


void main(void)
{
	unsigned char zkb;
	Time_Init();
	Init_D8253();
	PWM_Ctrl(0,70);
	PWM_Ctrl(1,120);
	PWM_Ctrl(2,200);
	while(1)
	{

		if(flag == 1)
		{
			zkb = (Get_Data[2] - '0')*100 + (Get_Data[3] - '0')*10 + (Get_Data[4] - '0'); 
			if(zkb>250)
				zkb = 250;
			switch(Get_Data[1])
			{
				case '0':	PWM_Ctrl(0,255-zkb);	break;
				case '1':	PWM_Ctrl(1,255-zkb);	break;
				case '2':	PWM_Ctrl(2,255-zkb);	break;			
			}
			flag = 0;
		}
	}




}
























