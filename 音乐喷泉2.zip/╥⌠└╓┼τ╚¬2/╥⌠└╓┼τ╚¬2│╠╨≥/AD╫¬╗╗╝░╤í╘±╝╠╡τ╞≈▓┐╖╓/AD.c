#include "reg52.h"
#include "intrins.h"
#include "stdlib.h"


sbit Select0 = P2^7;
sbit Select1 = P2^6;
sbit Select2 = P2^5;
sbit Select3 = P2^4;
sbit Key     = P2^3;

sbit LED0 = P3^2;
sbit LED1 = P3^3;
sbit LED2 = P3^4;
sbit LED3 = P3^5;
sbit LED4 = P3^6;
sbit LED5 = P3^7;

sbit CS0=P1^0; 		//ʹ�ܡ�
sbit CS1=P1^4; 		//ʹ�ܡ�
sbit CLK0=P1^1;		//ʱ��
sbit CLK1=P1^5;		//ʱ��
sbit DATA0 =P1^2; 	//�������
sbit DATA1 =P1^3;	
sbit DATA2 =P1^6;
sbit DATA3 =P1^7;

unsigned char V,V1,V2,V3,key,caculation,T0_Caculat,Second;

unsigned char Val0[7]={'@',0,0,0,0,'~','\0'};
unsigned char code Table[10]={0xfb,0x28,0x67,0x6e,0xac,0xce,0xcf,0x68,0xef,0xee};


void Delay_ms(unsigned int k)   //��� -0.651041666667us
{
	unsigned char a,b,c;
	for(c=k;c>0;c--)
	    for(b=102;b>0;b--)
	        for(a=3;a>0;a--);
}
void Delay400us(void)   //��� 0us
{
    unsigned char a,b;
    for(b=1;b>0;b--)
        for(a=43;a>0;a--);
}


unsigned char Get_ADCVal(unsigned char CH)
{
	unsigned char i,test,adval,dat;
	adval = 0x00;
	test = 0x00;
	if(CH < 2)
	{
		CLK0 = 0;       //��ʼ��
		DATA1 = 1;
		_nop_();
		CS0 = 0;
		_nop_();
		CLK0 = 1;
		_nop_();
		if ( CH == 0x00 )      //ͨ��ѡ��
		{
			CLK0 = 0;
			DATA1 = 1;      //ͨ��0�ĵ�һλ
			_nop_();
			CLK0 = 1;
			_nop_();
			CLK0 = 0;
			DATA1 = 0;      //ͨ��0�ĵڶ�λ
			_nop_();
			CLK0 = 1;
			_nop_();
		}
		else
		{
			CLK0 = 0;
			DATA1 = 1;      //ͨ��1�ĵ�һλ
			_nop_();
			CLK0 = 1;
			_nop_();
			CLK0 = 0;
			DATA1 = 1;      //ͨ��1�ĵڶ�λ
			_nop_();
			CLK0 = 1;
			_nop_();
		}
		CLK0 = 0;
		DATA1 = 1;
		for( i = 0;i < 8;i++ )      //��ȡǰ8λ��ֵ
		{
			_nop_();
			adval <<= 1;
			CLK0 = 1;
			_nop_();
			CLK0 = 0;
			if (DATA0)
				adval |= 0x01;
			else
				adval |= 0x00;
		}
		for (i = 0; i < 8; i++)      //��ȡ��8λ��ֵ
		{
			test >>= 1;
			if (DATA0)
				test |= 0x80;
			else
				test |= 0x00;
			_nop_();
			CLK0 = 1;
			_nop_();
			CLK0 = 0;
		}
		if (adval == test)      //�Ƚ�ǰ8λ���8λ��ֵ���������ͬ��ȥ����һֱ������ʾΪ�㣬�뽫����ȥ��
			dat = test;
		_nop_();
		CS0 = 1;        //�ͷ�ADC0832
		DATA0 = 1;
		CLK0 = 1;	
	}
	else
	{
		CLK1 = 0;       //��ʼ��
		DATA3 = 1;
		_nop_();
		CS1 = 0;
		_nop_();
		CLK1 = 1;
		_nop_();
		CLK1 = 0;
		DATA3 = 1;      //ͨ��1�ĵ�һλ
		_nop_();
		CLK1 = 1;
		_nop_();
		CLK1 = 0;
		DATA3 = 1;      //ͨ��1�ĵڶ�λ
		_nop_();
		CLK1 = 1;
		_nop_();
		CLK1 = 0;
		DATA3 = 1;
		for( i = 0;i < 8;i++ )      //��ȡǰ8λ��ֵ
		{
			_nop_();
			adval <<= 1;
			CLK1 = 1;
			_nop_();
			CLK1 = 0;
			if (DATA2)
				adval |= 0x01;
			else
				adval |= 0x00;
		}
		for (i = 0; i < 8; i++)      //��ȡ��8λ��ֵ
		{
			test >>= 1;
			if (DATA2)
				test |= 0x80;
			else
				test |= 0x00;
			_nop_();
			CLK1 = 1;
			_nop_();
			CLK1 = 0;
		}
		if (adval == test)      //�Ƚ�ǰ8λ���8λ��ֵ���������ͬ��ȥ����һֱ������ʾΪ�㣬�뽫����ȥ��
			dat = test;
		_nop_();
		CS1 = 1;        //�ͷ�ADC0832
		DATA2 = 1;
		CLK1 = 1;	
	}
	return dat;
}


void LED_Display(unsigned char NUM1,unsigned char NUM2,unsigned char NUM3)
{
	LED0 = 1;
	LED1 = 1;
	LED2 = 1;
	LED3 = 1;
	LED4 = 1;
	LED5 = 1;

	P0 = Table[NUM1/10];
	LED0 = 0;
	Delay400us();
	LED0 = 1;

	P0 = Table[NUM1%10];	
	LED1 = 0;
	Delay400us();
	LED1 = 1;

	P0 = Table[NUM2/10];	
	LED2 = 0;
	Delay400us();
	LED2 = 1;

	P0 = Table[NUM2%10];	
	LED3 = 0;
	Delay400us();
	LED3 = 1;

	P0 = Table[NUM3/10];	
	LED4 = 0;
	Delay400us();
	LED4 = 1;

	P0 = Table[NUM3%10];	
	LED5 = 0;
	Delay400us();
	LED5 = 1;
}

void Init_UART()
{
    TMOD |= 0x21;
    SCON |= 0x50;
    TH0 = 0x0B8;
    TL0 = 0x00;
    TH1 = 0xFD;
    TL1 = TH1;
    PCON = 0x00;
	EA = 1;
    ET0 = 1;
    TR0 = 1;
    TR1 = 1; 
}
void Send_one_word(unsigned char word)
{
	SBUF = word;
	while(!TI);
	TI = 0;
}
void Send_Words(unsigned char *p)	//һ���ַ���ʱ1ms
{
	while(*p!='\0')
		Send_one_word(*p++);
	Send_one_word('\0');	
}


void Way_Select(unsigned char way)
{
	switch(way)
	{
		case 0:
		{
			Select0 = 0;						
			Select1 = 0;
			Select2 = 0;
			Select3 = 1;
		}break;
		case 1:
		{
			Select0 = 0;						
			Select1 = 0;
			Select2 = 1;
			Select3 = 0;
		}break;
		case 2:
		{
			Select0 = 0;						
			Select1 = 1;
			Select2 = 0;
			Select3 = 0;
		}break;
		case 3:
		{
			Select0 = 1;						
			Select1 = 0;
			Select2 = 0;
			Select3 = 0;
		}break;
	}
}


void Timer0Interrupt(void) interrupt 1
{
    TH0 = 0xB8;
    TL0 = 0x00;
	caculation++;
	T0_Caculat++;
	if(T0_Caculat == 50)	  //һ��
	{
		T0_Caculat = 0;
		Second++;
		if(Second == 180)		  //������
		{
			Second = 0;
			Way_Select((V1+V2+V3)%4);
		}
	}	
	if(caculation == 3)
		caculation = 0;
	V = (Get_ADCVal(caculation)/2)+70;
	Val0[1] = caculation + 48;
	Val0[2] = V / 100 + 48;
	Val0[3] = (V % 100) / 10 + 48 ;
	Val0[4] = (V % 10) + 48;  
	Send_Words(Val0);
	if(caculation==0)
		V1 = V;
	else if(caculation==1)
		V2 = V;
	else if(caculation==2)
		V3 = V;	
}





void KeyBoard(void)
{
	Key = 0;
	if(Key == 1)
	{
		Delay_ms(10);
		if(Key == 1)
		{
			key++;
			if(key == 4)
				key = 0;
			Way_Select(key);
			while(Key==1)
			{
				LED_Display(V3/2.6,V1/2.6,V2/2.6);
				Delay_ms(5);
			}	
		}
	}		
}


void main(void)
{
	Init_UART();
	Delay_ms(50);
	Way_Select((V1+V2+V3)%4);	 //���ѡ��һ·��Դ



	while(1)
	{	

		KeyBoard();
		LED_Display(V3/2.6,V1/2.6,V2/2.6);
	
	}





}














