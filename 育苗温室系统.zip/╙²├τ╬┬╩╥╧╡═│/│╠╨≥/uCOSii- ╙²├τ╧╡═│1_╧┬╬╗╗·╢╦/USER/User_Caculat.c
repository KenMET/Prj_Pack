#include "User_Caculat.h"









//BH1750����
OS_STK User_TASK_STK[User_STK_SIZE];
void User_Task(void *pdata)
{	 	
	Log_Uartx("Task Of User Created...\n");
	while(1)
	{
		
		CAN_Send_Ch_Val(4,Tem_Air_In);
		Delay_ms(10);
		CAN_Send_Ch_Val(5,Tem_Dirt);
		Delay_ms(10);
		CAN_Send_Ch_Val(6,Tem_Air_Out);
		Delay_ms(10);
		CAN_Send_Ch_Val(7,Hum_Dirt);
		Delay_ms(10);
		CAN_Send_Ch_Val(8,DHT_Air_In);
		Delay_ms(10);
		CAN_Send_Ch_Val(9,DHT_Air_Out);
		Delay_ms(1000);	
	}
}









