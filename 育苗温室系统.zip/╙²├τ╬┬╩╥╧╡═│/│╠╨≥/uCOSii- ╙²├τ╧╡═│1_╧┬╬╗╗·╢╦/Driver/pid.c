#include "pid.h"
#include <math.h>





void PidInit(PID_Struct * pid, float p, float i, float d, float dt)	   
{
	pid->epsilon = 0.1;
	pid->MAX = 779;
	pid->MIN = 0;
	pid->Kp = p;
	pid->Ki = i;
	pid->Kd = d;
	pid->dt = dt;
	pid->pre_error = 0;
	pid->integral = 0;
}
float FABSF(float x)
{
	if(x < 0)
	x = -1*x;
	return x;
}
float PidCalc(PID_Struct * pid, float setpoint, float input)
{
	float error, derivative, output;

	error = setpoint - input;

	if (FABSF(error) > pid->epsilon)
		pid->integral += error * pid->dt;				//����
	derivative = (error - pid->pre_error) / pid->dt;	//΢��
	output = pid->Kp * error							//������
		   + pid->Ki * pid->integral 					//������
		   + pid->Kd * derivative;						//΢����
	if (output > pid->MAX)								
		output = pid->MAX;								//�������ֵ
	else if (output < pid->MIN)							
		output = pid->MIN;								//������Сֵ
	pid->pre_error = error;
	
	return output;
}
