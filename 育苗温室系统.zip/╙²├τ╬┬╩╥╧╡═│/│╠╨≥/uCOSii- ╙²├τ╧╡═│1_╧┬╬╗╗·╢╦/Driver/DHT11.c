#include "DHT11.h"



unsigned char DHT_Dat1[2]={0,0};
unsigned char DHT_Dat2[2]={0,0};

unsigned char DHT_Init(void)
{	 
	uint8_t Check=0;
 	GPIO_InitTypeDef  GPIO_InitStructure;
 	
 	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);	 //ʹ�ܶ˿�ʱ��
	
 	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3|GPIO_Pin_4;				 //�˿�����
 	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; 		 //�������
 	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
 	GPIO_Init(GPIOA, &GPIO_InitStructure);				 //��ʼ��IO��
 	
	DHT_SDA1_Out = 1;	
	DHT_SDA2_Out = 1;		

	DHT1_Rst();  //��λDHT11
	DHT2_Rst();  //��λDHT11
	Check = 	DHT1_Check();
	Check +=	DHT2_Check();
	return Check;//�ȴ�DHT11�Ļ�Ӧ
} 

//��λDHT
void DHT1_Rst(void)	   
{                 
	DHT_SDA1_OUT(); 	//SET OUTPUT
	DHT_SDA1_Out=0; 	//����DQ
	Delay_ms(20);    	//��������18ms
	DHT_SDA1_Out=1; 	//DQ=1 
	Delay_us(30);     	//��������20~40us
}
void DHT2_Rst(void)	   
{                 
	DHT_SDA2_OUT(); 	//SET OUTPUT
	DHT_SDA2_Out=0; 	//����DQ
	Delay_ms(20);    	//��������18ms
	DHT_SDA2_Out=1; 	//DQ=1 
	Delay_us(30);     	//��������20~40us
}
//
//���DHT
unsigned char DHT1_Check(void) 	   
{   
	unsigned char retry=0;
	DHT_SDA1_IN();//SET INPUT	 
  while (DHT_SDA1_In&&retry<100)//DHT11������40~80us
	{
		retry++;
		Delay_us(1);
	}
	if(retry>=100)
		return 1;
	else 
		retry=0;
  while (!DHT_SDA1_In&&retry<100)//DHT11���ͺ���ٴ�����40~80us
	{
		retry++;
		Delay_us(1);
	}
	if(retry>=100)return 1;	    
	return 0;
}
unsigned char DHT2_Check(void) 	   
{   
	unsigned char retry=0;
	DHT_SDA2_IN();//SET INPUT	 
  while (DHT_SDA2_In&&retry<100)//DHT11������40~80us
	{
		retry++;
		Delay_us(1);
	}
	if(retry>=100)
		return 1;
	else 
		retry=0;
  while (!DHT_SDA2_In&&retry<100)//DHT11���ͺ���ٴ�����40~80us
	{
		retry++;
		Delay_us(1);
	}
	if(retry>=100)return 1;	    
	return 0;
}
//
//����һλ
unsigned char DHT11_Read_Bit(void) 			 
{
 	unsigned char retry=0;
	while(DHT_SDA1_In&&retry<100)//�ȴ���Ϊ�͵�ƽ
	{
		retry++;
		Delay_us(1);
	}
	retry=0;
	while(!DHT_SDA1_In&&retry<100)//�ȴ���ߵ�ƽ
	{
		retry++;
		Delay_us(1);
	}
	Delay_us(40);//�ȴ�40us
	if(DHT_SDA1_In)return 1;
	else return 0;		   
}
unsigned char DHT12_Read_Bit(void) 			 
{
 	unsigned char retry=0;
	while(DHT_SDA2_In&&retry<100)//�ȴ���Ϊ�͵�ƽ
	{
		retry++;
		Delay_us(1);
	}
	retry=0;
	while(!DHT_SDA2_In&&retry<100)//�ȴ���ߵ�ƽ
	{
		retry++;
		Delay_us(1);
	}
	Delay_us(40);//�ȴ�40us
	if(DHT_SDA2_In)return 1;
	else return 0;		   
}
//
//����һ���ֽ�
unsigned char Read_8Bit_DHT1(void)    
{        
	unsigned char i,dat=0;
	for (i=0;i<8;i++) 
	{
		dat<<=1; 
		dat|=DHT11_Read_Bit();
	}						    
	return dat;
}
unsigned char Read_8Bit_DHT2(void)    
{        
	unsigned char i,dat=0;
	for (i=0;i<8;i++) 
	{
		dat<<=1; 
		dat|=DHT12_Read_Bit();
	}						    
	return dat;
}
//
//��ȡDHTʪ��
unsigned char Read_DHT(unsigned char CH)
{
 	unsigned char buf[5];
	unsigned char i;
	switch(CH)
	{
		case 1:
			DHT1_Rst();
			if(DHT1_Check()==0)
			{
				for(i=0;i<5;i++)//��ȡ40λ����
				{
					buf[i]=Read_8Bit_DHT1();
				}
				if((buf[0]+buf[1]+buf[2]+buf[3])==buf[4])
					return buf[0];
			}
		break;
		case 2:
			DHT2_Rst();
			if(DHT2_Check()==0)
			{
				for(i=0;i<5;i++)//��ȡ40λ����
				{
					buf[i]=Read_8Bit_DHT2();
				}
				if((buf[0]+buf[1]+buf[2]+buf[3])==buf[4])
					return buf[0];
			}
		break;
	}
	return 0;
}


unsigned char DHT_Air_Out,DHT_Air_In;
//DHT����
OS_STK DHT_TASK_STK[DHT_STK_SIZE];
void DHT_Task(void *pdata)
{	 	
	
	Log_Uartx("Task Of DHT Created...\n");
	while(1)
	{
		Delay_ms(2100);
		DHT_Air_Out = Read_DHT(1);
		DHT_Air_In = Read_DHT(2);

	}
}









