#include "DS18B20.h"




void DS18B20_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB|RCC_APB2Periph_AFIO, ENABLE);
	
	GPIO_PinRemapConfig(GPIO_Remap_SWJ_JTAGDisable , ENABLE);
	//GPIO_Remap_SWJ_JTAG Disable ,JTAG-DP Disable + SW-DP Enable

	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3|GPIO_Pin_4|GPIO_Pin_5;			
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(GPIOB, &GPIO_InitStructure);
	
	DS_SDA1_OUT();
	DS_SDA2_OUT();
	DS_SDA3_OUT();
}
//

//��λDS18B20
void DS18B20_CH1_Rst(void)	   
{                 
	DS_SDA1_OUT();
  DS18B20_SDA1_Out=0; //����DQ
  Delay_us(750);    //����750us
  DS18B20_SDA1_Out=1; //DQ=1 
	Delay_us(15);     //15US
}
void DS18B20_CH2_Rst(void)	   
{                 
	DS_SDA2_OUT();
  DS18B20_SDA2_Out=0; //����DQ
  Delay_us(750);    //����750us
  DS18B20_SDA2_Out=1; //DQ=1 
	Delay_us(15);     //15US
}
void DS18B20_CH3_Rst(void)	   
{                 
	DS_SDA3_OUT();
  DS18B20_SDA3_Out=0; //����DQ
  Delay_us(750);    //����750us
  DS18B20_SDA3_Out=1; //DQ=1 
	Delay_us(15);     //15US
}
//

//д��һ���ֽ�
void DS18B20_CH1_WriteByte(unsigned char dat)  
{  
	u8 j;
	u8 testb;
	DS_SDA1_OUT();//SET PA0 OUTPUT;
	for (j=1;j<=8;j++) 
	{
		testb=dat&0x01;
		dat=dat>>1;
		if (testb) 
		{
			DS18B20_SDA1_Out=0;// Write 1
			Delay_us(2);                            
			DS18B20_SDA1_Out=1;
			Delay_us(60);             
		}
		else 
		{
			DS18B20_SDA1_Out=0;// Write 0
			Delay_us(60);             
			DS18B20_SDA1_Out=1;
			Delay_us(2);                          
		}
	} 
}
void DS18B20_CH2_WriteByte(unsigned char dat)  
{  
	u8 j;
	u8 testb;
	DS_SDA2_OUT();//SET PA0 OUTPUT;
	for (j=1;j<=8;j++) 
	{
		testb=dat&0x01;
		dat=dat>>1;
		if (testb) 
		{
			DS18B20_SDA2_Out=0;// Write 1
			Delay_us(2);                            
			DS18B20_SDA2_Out=1;
			Delay_us(60);             
		}
		else 
		{
			DS18B20_SDA2_Out=0;// Write 0
			Delay_us(60);             
			DS18B20_SDA2_Out=1;
			Delay_us(2);                          
		}
	} 
}
void DS18B20_CH3_WriteByte(unsigned char dat)  
{  
	u8 j;
	u8 testb;
	DS_SDA3_OUT();//SET PA0 OUTPUT;
	for (j=1;j<=8;j++) 
	{
		testb=dat&0x01;
		dat=dat>>1;
		if (testb) 
		{
			DS18B20_SDA3_Out=0;// Write 1
			Delay_us(2);                            
			DS18B20_SDA3_Out=1;
			Delay_us(60);             
		}
		else 
		{
			DS18B20_SDA3_Out=0;// Write 0
			Delay_us(60);             
			DS18B20_SDA3_Out=1;
			Delay_us(2);                          
		}
	} 
}
//

//����һλ
unsigned char DS18B20_CH1_ReadBit(void)   
{  
	u8 data;
	DS_SDA1_OUT();//SET PA0 OUTPUT
  DS18B20_SDA1_Out=0; 
	Delay_us(2);
  DS18B20_SDA1_Out=1; 
	DS_SDA1_IN();//SET PA0 INPUT
	Delay_us(12);
	if(DS18B20_SDA1_In)
		data=1;
  else 
		data=0;	 
  Delay_us(50);           
  return data;
}
unsigned char DS18B20_CH2_ReadBit(void)   
{  
	u8 data;
	DS_SDA2_OUT();//SET PA0 OUTPUT
  DS18B20_SDA2_Out=0; 
	Delay_us(2);
  DS18B20_SDA2_Out=1; 
	DS_SDA2_IN();//SET PA0 INPUT
	Delay_us(12);
	if(DS18B20_SDA2_In)
		data=1;
  else 
		data=0;	 
  Delay_us(50);           
  return data;
}
unsigned char DS18B20_CH3_ReadBit(void)   
{  
	u8 data;
	DS_SDA3_OUT();//SET PA0 OUTPUT
  DS18B20_SDA3_Out=0; 
	Delay_us(2);
  DS18B20_SDA3_Out=1; 
	DS_SDA3_IN();//SET PA0 INPUT
	Delay_us(12);
	if(DS18B20_SDA3_In)
		data=1;
  else 
		data=0;	 
  Delay_us(50);           
  return data;
}
//
//����һ���ֽ�
unsigned char DS18B20_CH1_ReadByte(void)
{
	unsigned char i,j,dat;
	dat=0;
	for (i=1;i<=8;i++) 
	{
		j=DS18B20_CH1_ReadBit();
		dat=(j<<7)|(dat>>1);
	}						    
	return dat;
}
unsigned char DS18B20_CH2_ReadByte(void)
{
	unsigned char i,j,dat;
	dat=0;
	for (i=1;i<=8;i++) 
	{
		j=DS18B20_CH2_ReadBit();
		dat=(j<<7)|(dat>>1);
	}						    
	return dat;
}
unsigned char DS18B20_CH3_ReadByte(void)
{
	unsigned char i,j,dat;
	dat=0;
	for (i=1;i<=8;i++) 
	{
		j=DS18B20_CH3_ReadBit();
		dat=(j<<7)|(dat>>1);
	}						    
	return dat;
}
//
//�ȴ�DS18B20�Ļ�Ӧ
//����1:δ��⵽DS18B20�Ĵ���
//����0:����
unsigned char DS18B20_CH1_Check(void) 	   
{   
	u8 retry=0;
	DS_SDA1_IN();//SET PA0 INPUT	 
  while (DS18B20_SDA1_In&&retry<200)
	{
		retry++;
		Delay_us(1);
	}	 
	if(retry>=200)
		return 1;
	else 
		retry=0;
  while (!DS18B20_SDA1_In&&retry<240)
	{
		retry++;
		Delay_us(1);
	}
	if(retry>=240)
		return 1;	    
	return 0;
}
unsigned char DS18B20_CH2_Check(void) 	   
{   
	u8 retry=0;
	DS_SDA2_IN();//SET PA0 INPUT	 
  while (DS18B20_SDA2_In&&retry<200)
	{
		retry++;
		Delay_us(1);
	}	 
	if(retry>=200)
		return 1;
	else 
		retry=0;
  while (!DS18B20_SDA2_In&&retry<240)
	{
		retry++;
		Delay_us(1);
	}
	if(retry>=240)
		return 1;	    
	return 0;
}
unsigned char DS18B20_CH3_Check(void) 	   
{   
	u8 retry=0;
	DS_SDA3_IN();//SET PA0 INPUT	 
  while (DS18B20_SDA3_In&&retry<200)
	{
		retry++;
		Delay_us(1);
	}	 
	if(retry>=200)
		return 1;
	else 
		retry=0;
  while (!DS18B20_SDA3_In&&retry<240)
	{
		retry++;
		Delay_us(1);
	}
	if(retry>=240)
		return 1;	    
	return 0;
}
//
//��ʼ�¶�ת��
void DS18B20_Start(unsigned char CH)// ds1820 start convert
{   					
	switch(CH)
	{
		case 1:
			DS18B20_CH1_Rst();	   
			DS18B20_CH1_Check();	 
			DS18B20_CH1_WriteByte(0xcc);// skip rom
			DS18B20_CH1_WriteByte(0x44);// convert			
		break;
		case 2:
			DS18B20_CH2_Rst();	   
			DS18B20_CH2_Check();	 
			DS18B20_CH2_WriteByte(0xcc);// skip rom
			DS18B20_CH2_WriteByte(0x44);// convert			
		break;
		case 3:
			DS18B20_CH3_Rst();	   
			DS18B20_CH3_Check();	 
			DS18B20_CH3_WriteByte(0xcc);// skip rom
			DS18B20_CH3_WriteByte(0x44);// convert			
		break;
	}
} 
//

short DS18B20_Get_Temp(unsigned char CH)
{
	u8 temp;
	u8 TL,TH;
	short tem;
	DS18B20_Start(CH);                    // ds1820 start convert
	switch(CH)
	{
		case 1:
			DS18B20_CH1_Rst();
			DS18B20_CH1_Check();	 
			DS18B20_CH1_WriteByte(0xcc);// skip rom
			DS18B20_CH1_WriteByte(0xbe);// convert	    
			TL=DS18B20_CH1_ReadByte(); // LSB   
			TH=DS18B20_CH1_ReadByte(); // MSB  			
		break;
		case 2:
			DS18B20_CH2_Rst();
			DS18B20_CH2_Check();	 
			DS18B20_CH2_WriteByte(0xcc);// skip rom
			DS18B20_CH2_WriteByte(0xbe);// convert	    
			TL=DS18B20_CH2_ReadByte(); // LSB   
			TH=DS18B20_CH2_ReadByte(); // MSB  			
		break;
		case 3:
			DS18B20_CH3_Rst();
			DS18B20_CH3_Check();	 
			DS18B20_CH3_WriteByte(0xcc);// skip rom
			DS18B20_CH3_WriteByte(0xbe);// convert	    
			TL=DS18B20_CH3_ReadByte(); // LSB   
			TH=DS18B20_CH3_ReadByte(); // MSB  			
		break;
	}
	if(TH>7)
	{
		TH=~TH;
		TL=~TL; 
		temp=0;//�¶�Ϊ��  
	}
	else 
		temp=1;//�¶�Ϊ��	  	  
	tem=TH; //��ø߰�λ
	tem<<=8;    
	tem+=TL;//��õװ�λ
	tem=(float)tem*0.625;//ת��     
	if(temp)			return tem; //�����¶�ֵ
	else 					return -tem;    
} 
//




short Tem_Dirt,Tem_Air_In,Tem_Air_Out;
//DS18B20����
OS_STK DS18B20_TASK_STK[DS18B20_STK_SIZE];
void DS18B20_Task(void *pdata)
{	 
	
	Log_Uartx("Task Of DS18B20 Created...\n");
	while(1)
	{
		Delay_ms(2000);
		Tem_Dirt 		= DS18B20_Get_Temp(3);
		Delay_ms(100);
		Tem_Air_In 	= DS18B20_Get_Temp(2);
		Delay_ms(100);
		Tem_Air_Out = DS18B20_Get_Temp(1);
		
		
	}
}







