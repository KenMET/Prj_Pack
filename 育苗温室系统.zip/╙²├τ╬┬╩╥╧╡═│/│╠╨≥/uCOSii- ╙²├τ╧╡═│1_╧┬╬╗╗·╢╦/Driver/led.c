#include "LED.h"

OS_STK LED_TASK_STK[LED_STK_SIZE];



void LED_Init(void)
{

	GPIO_InitTypeDef GPIO_InitStructure_LED;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);
	
	GPIO_InitStructure_LED.GPIO_Pin = GPIO_Pin_13|GPIO_Pin_14|GPIO_Pin_15;			
  GPIO_InitStructure_LED.GPIO_Mode = GPIO_Mode_Out_PP;
  GPIO_InitStructure_LED.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(GPIOC, &GPIO_InitStructure_LED);
	LED=1;
	CAN_Rx_LED = 1;
	CAN_Tx_LED = 1;
}


//LED����
void LED_Task(void *pdata)
{	 	
	Log_Uartx("Task Of LED Created...\n");
	while(1)
	{
		LED=0;
		Delay_ms(80);
		LED=1;
		Delay_ms(80);
		LED=0;
		Delay_ms(80);
		LED=1;
		Delay_ms(1500);
	}
}




