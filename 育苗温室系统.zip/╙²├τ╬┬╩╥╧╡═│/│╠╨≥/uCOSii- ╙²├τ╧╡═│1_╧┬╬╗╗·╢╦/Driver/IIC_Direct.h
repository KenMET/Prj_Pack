#ifndef _IIC_Direct_H_
#define	_IIC_Direct_H_

#include "stm32f10x.h"
#include "stm32f10x_i2c.h"
#include "includes.h"

#define true 1
#define false 0 

#define TRUE  0
#define FALSE -1

#define  I2C_Direction_Transmitter      ((uint8_t)0x00)	//д
#define  I2C_Direction_Receiver         ((uint8_t)0x01)	//��




#define SDA1_IN()  {GPIOB->CRH&=0XFF0FFFFF;GPIOB->CRH|=0x00800000;} //����ģʽ
#define SDA1_OUT() {GPIOB->CRH&=0XFF0FFFFF;GPIOB->CRH|=0x00300000;} //���ģʽ

#define SDA2_IN()  {GPIOB->CRH&=0X0FFFFFFF;GPIOB->CRH|=0x80000000;} //����ģʽ
#define SDA2_OUT() {GPIOB->CRH&=0X0FFFFFFF;GPIOB->CRH|=0x30000000;} //���ģʽ

#define SDA3_IN()  {GPIOB->CRL&=0XFFF0FFFF;GPIOB->CRL|=0x00080000;} //����ģʽ
#define SDA3_OUT() {GPIOB->CRL&=0XFFF0FFFF;GPIOB->CRL|=0x00030000;} //���ģʽ


#define IIC_SCL1    PBout(12) //SCL
#define IIC_SDA1    PBout(13) //SDA
#define READ_SDA1   PBin(13)  //����SDA 

#define IIC_SCL2    PBout(14) //SCL
#define IIC_SDA2    PBout(15) //SDA
#define READ_SDA2   PBin(15)  //����SDA 

#define IIC_SCL3    PBout(3) //SCL
#define IIC_SDA3    PBout(4) //SDA
#define READ_SDA3   PBin(4)  //����SDA 


 
 
//IIC���в�������
extern void IIC1_Start(void);
extern void IIC2_Start(void);
extern void IIC3_Start(void);
extern void IIC1_Stop(void);
extern void IIC2_Stop(void);
extern void IIC3_Stop(void);
extern u8 IIC1_Wait_Ack(void);
extern u8 IIC2_Wait_Ack(void);
extern u8 IIC3_Wait_Ack(void);
extern void IIC1_Ack(void);
extern void IIC2_Ack(void);
extern void IIC3_Ack(void);
extern void IIC1_NAck(void);
extern void IIC2_NAck(void);
extern void IIC3_NAck(void);

extern void IIC_Init(void);                					//��ʼ��IIC��IO��			

extern void IIC1_Send_Byte(u8 txd);
extern void IIC2_Send_Byte(u8 txd);
extern void IIC3_Send_Byte(u8 txd);
extern u8 IIC1_Read_Byte(void);
extern u8 IIC2_Read_Byte(void);
extern u8 IIC3_Read_Byte(void);



#endif
