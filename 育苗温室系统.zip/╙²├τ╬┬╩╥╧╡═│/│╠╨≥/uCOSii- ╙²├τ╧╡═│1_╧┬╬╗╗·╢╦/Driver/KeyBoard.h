#ifndef __KeyBoard_H_
#define __KeyBoard_H_

#include "sys.h"
#include "stm32f10x.h"
#include "stm32f10x_conf.h"

//4X4����ʹ��PA8~PA15
/*************������ʹ�õ�IO��**************/
#define RCC_Key 	RCC_APB2Periph_GPIOA	
#define GPIO_Key 	GPIOA
/**************8λKey_I/O��IO�ڶ���************/
#define PIN_Key_L 	(GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_2 | GPIO_Pin_3)
#define PIN_Key_H 	(GPIO_Pin_4 | GPIO_Pin_5 | GPIO_Pin_6 | GPIO_Pin_7)

#define RCC_Key_Single 			RCC_APB2Periph_GPIOB	
#define GPIO_Key_Single 		GPIOB
#define PIN_Key_Single 			GPIO_Pin_5|GPIO_Pin_12

#define KEY1 PBin(5)
#define KEY2 PBin(12)

extern void KeyScan(void);
extern void KeyBoard_Init(void);
extern void Single_KeyBoard_Init(void);
extern unsigned char real_key(unsigned char KEY);
extern unsigned char Get_Single_Key(void);

#endif
