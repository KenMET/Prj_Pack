#ifndef _EXTI_H_
#define _EXTI_H_

//UCOSii�����ļ�����
#include "includes.h"

#include "stm32f10x.h"
#include "stm32f10x_exti.h"


#define GPIO_Pin_MPU	 							GPIO_Pin_7
#define GPIO_Pin_SPI1	 							GPIO_Pin_6
#define GPIO_Pin_SPI2	 							GPIO_Pin_5
#define GPIO_PinSourceEXTI_MPU 			GPIO_PinSource7
#define GPIO_PinSourceEXTI_SPI1 		GPIO_PinSource6
#define GPIO_PinSourceEXTI_SPI2 		GPIO_PinSource5
#define EXTI_LINE_MPU 							EXTI_Line7
#define EXTI_LINE_SPI1							EXTI_Line3
#define EXTI_LINE_SPI2							EXTI_Line5

#define GPIO_PortSourceEXTI_MPU 		GPIO_PortSourceGPIOA
#define GPIO_PortSourceEXTI_SPI1 		GPIO_PortSourceGPIOB
#define GPIO_PortSourceEXTI_SPI2 		GPIO_PortSourceGPIOB
#define GPIO_Port_MPU  							GPIOA
#define GPIO_Port_SPI1  						GPIOB
#define GPIO_Port_SPI2  						GPIOB

extern void My_EXTI_Init(void);


#endif
