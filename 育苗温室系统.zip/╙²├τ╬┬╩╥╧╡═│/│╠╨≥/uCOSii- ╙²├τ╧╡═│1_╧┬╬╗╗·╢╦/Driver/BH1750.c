#include "BH1750.h"



void BH1750_Init(void)
{
	IIC_Init();
	BH1750_Write_Byte(0x01,1); 
	BH1750_Write_Byte(0x01,3); 
}
//
void BH1750_Start(unsigned char CH)
{
	BH1750_Write_Byte(BH1750_ON,CH);	 //power on
	BH1750_Write_Byte(BH1750_RSET,CH);	//clear
	BH1750_Write_Byte(BH1750_ONE,CH);  
}
//
void BH1750_Write_Byte(unsigned char Cmd,unsigned char CH)
{
	switch(CH)
	{
		case 1:
			IIC1_Start();                  	//��ʼ�ź�
			IIC1_Send_Byte(BH1750_Addr+0);  //�����豸��ַ+д�ź�
			while(IIC1_Wait_Ack()){}
			IIC1_Send_Byte(Cmd);    					
			while(IIC1_Wait_Ack()){}
			IIC1_Stop();             			 //����ֹͣ�ź� 
		break;
		case 2:
			IIC2_Start();                  	//��ʼ�ź�
			IIC2_Send_Byte(BH1750_Addr+0);  //�����豸��ַ+д�ź�
			while(IIC2_Wait_Ack()){}
			IIC2_Send_Byte(Cmd);    					
			while(IIC2_Wait_Ack()){}
			IIC2_Stop();             			 //����ֹͣ�ź� 
		break;
		case 3:
			IIC3_Start();                  	//��ʼ�ź�
			IIC3_Send_Byte(BH1750_Addr+0);  //�����豸��ַ+д�ź�
			while(IIC3_Wait_Ack()){}
			IIC3_Send_Byte(Cmd);    					
			while(IIC3_Wait_Ack()){}
			IIC3_Stop();             			 //����ֹͣ�ź� 
		break;
	}
	Delay_ms(5);
}
//
unsigned short Read_BH1750(unsigned char CH)		//��ȡ��ϳ����ݲ�����
{   	
	unsigned short Lux=0;
	switch(CH)
	{
		case 1:
			IIC1_Start();                          
			IIC1_Send_Byte(BH1750_Addr+1);        
			while(IIC1_Wait_Ack()){}
			Lux=IIC1_Read_Byte();  
			IIC1_Ack();
			Lux <<= 8;
			Lux|=IIC1_Read_Byte(); 		
			IIC1_NAck();
			IIC1_Stop(); 			
		break;
		case 2:
			IIC2_Start();                          
			IIC2_Send_Byte(BH1750_Addr+1);        
			while(IIC2_Wait_Ack()){}
			Lux=IIC2_Read_Byte();  
			IIC2_Ack();
			Lux <<= 8;
			Lux|=IIC2_Read_Byte(); 		
			IIC2_NAck();
			IIC2_Stop(); 			
		break;
		case 3:
			IIC3_Start();                          
			IIC3_Send_Byte(BH1750_Addr+1);        
			while(IIC3_Wait_Ack()){}
			Lux=IIC3_Read_Byte();  
			IIC3_Ack();
			Lux <<= 8;
			Lux|=IIC3_Read_Byte(); 		
			IIC3_NAck();
			IIC3_Stop(); 			
		break;		
	}     
	return (float)Lux/1.2;
}

//BH1750����
OS_STK BH1750_TASK_STK[BH1750_STK_SIZE];
void BH1750_Task(void *pdata)
{	 	
	Log_Uartx("Task Of BH1750 Created...\n");
	while(1)
	{
		BH1750_Start(1);  //power on
		Delay_ms(180); 
		printf("Lux1:%d\n",Read_BH1750(1));
		
		BH1750_Start(3);  //power on
		Delay_ms(180); 
		printf("Lux3:%d\n",Read_BH1750(3));
		
		Delay_ms(1000);	

	}
}

