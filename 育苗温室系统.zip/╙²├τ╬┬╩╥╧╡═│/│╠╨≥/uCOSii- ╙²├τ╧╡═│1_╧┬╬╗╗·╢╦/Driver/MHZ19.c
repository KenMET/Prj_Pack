#include "MHZ19.h"

unsigned int MHZ19_CO2=0;

unsigned char Check_CO2(int8_t *dat)
{
	unsigned char k,Temp=0;
	for(k=1;k<8;k++)
		Temp += (uint8_t)dat[k];
	Temp = 0xff - Temp + 1;
	return Temp;
}

unsigned int MHZ19_Read(void)
{
	unsigned int Temp;
	unsigned char Cmd[9]={0xff,0x01,0x86,0x00,0x00,0x00,0x00,0x00,0x79};
	
	MHZ19_Uartx(Cmd,9);	//��co2��������������
	Delay_ms(2000);	
	if(Usart3_Situation != 0)
	{
		Temp = Got_Usart3_Data[2]*256 + Got_Usart3_Data[3];
		Usart3_Finish = 0;
		Usart3_Situation = 0;
		Clean_Str(Got_Usart3_Data,USART_REC_LEN);
		if(Check_CO2(Got_Usart3_Data) == Got_Usart3_Data[8])
			return Temp;
	}
	else
		Log_Uartx("N0 MHZ19 Data...\n");
	return 0;
}





//MHZ19����
OS_STK MHZ19_TASK_STK[MHZ19_STK_SIZE];
void MHZ19_Task(void *pdata)
{	 	
	unsigned char First=0,k;
	Log_Uartx("Task Of MHZ19 Created...\n");
	while(1)
	{
		if(First)
		{
			for(k=60;k>0;k--)
			{
				printf("Wait MHZ19...%dsec\n",(k*5));
				Delay_ms(5000);		
			}
			First = 0;
		}
		else
		{
			MHZ19_CO2 = MHZ19_Read();
			Delay_ms(3000);	
		}
	}
}












