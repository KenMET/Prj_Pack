#include "ESP8266.h"
					   
unsigned char length_str[18]="AT+CIPSEND=0,";


void ESP8266_Init()
{
	Send_AT_Cmd("ATE0","OK",3,210);					  	//ȡ������
	Send_AT_Cmd("AT+CWMODE_DEF=1","OK",3,210);		  	//stationģʽ
	Send_AT_Cmd("AT+CWDHCP_DEF=1,1","OK",3,210);		  	//��DHCPģʽ
	Send_AT_Cmd("AT+CIPSTO=0","OK",3,210);			  	//��������ʱ���Ͽ�
	Send_AT_Cmd("AT+CIPMUX=1","OK",3,210);			  	//������ͻ�����ģʽ
	Send_AT_Cmd("AT+CIPSERVER=1,5008","OK",3,210); 		//���÷������˿�	
}




void ESP8266_Send(unsigned char *Words)
{
	uint16_t length;
	length = strlen(Words);
	if(length >= 1000)
	{
		length_str[13] = length/1000 + 48;
		length_str[14] = (length%1000)/100 + 48;
		length_str[15] = (length%100)/10 + 48;
		length_str[16] = length%10 + 48;	
	}
	else if(length >= 100 && length < 1000)
	{
		length_str[13] = length/100 + 48;
		length_str[14] = (length%100)/10 + 48;
		length_str[15] = length%10 + 48;
	}
	else if(length >= 10 && length < 100)
	{
		length_str[13] = length/10 + 48;
		length_str[14] = length%10 + 48;
	}
	else
		length_str[13] = length + 48;		
	Send_AT_Cmd(length_str,">",3,100);	
	Usart3_SendString(Words);
}



















