#ifndef _SPI_H_
#define _SPI_H_
#include "stm32f10x.h"
#include "stm32f10x_spi.h"
/*
		�ǵð�MOSI��MISO�񴮿ڵ�RXTX����.......
*/

#define SPI1_CE_H()   GPIO_SetBits(GPIOB, GPIO_Pin_7) 
#define SPI1_CE_L()   GPIO_ResetBits(GPIOB, GPIO_Pin_7)

#define SPI1_CSN_H()  GPIO_SetBits(GPIOB, GPIO_Pin_8)
#define SPI1_CSN_L()  GPIO_ResetBits(GPIOB, GPIO_Pin_8)

#define SPI2_CE_H()   GPIO_SetBits(GPIOA, GPIO_Pin_8) 
#define SPI2_CE_L()   GPIO_ResetBits(GPIOA, GPIO_Pin_8)

#define SPI2_CSN_H()  GPIO_SetBits(GPIOB, GPIO_Pin_12)
#define SPI2_CSN_L()  GPIO_ResetBits(GPIOB, GPIO_Pin_12)

extern void SPI1_INIT(void);
extern void SPI2_INIT(void);
void SPI1_SetSpeed(u8 SPI_BaudRatePrescaler);
void SPI2_SetSpeed(u8 SPI_BaudRatePrescaler);
u8 SPI1_RW(u8 dat);
u8 SPI2_RW(u8 dat);


#endif

