#include "User_Caculat.h"


unsigned short Lux_In,Lux_Out;
unsigned short MHZ19_CO2;

void Window_Move(signed short PWM)
{
	if(PWM<0)
	{
		PWM_Ctrl_1(-PWM);
		PWM_Ctrl_2(0);	
	}
	else
	{
		PWM_Ctrl_1(0);
		PWM_Ctrl_2(PWM);	
	}
}

void Window_Sta(bool Sta)
{
	if(Sta == OPEN)
	{
		Window_Move(400);
		while(Ir == 1){Delay_ms(50);}
		Delay_ms(50);
		while(Ir == 1){Delay_ms(50);}
		Window_Move(0);
	}
	else
	{
		Code_Num = 0;
		Window_Move(-400);
		Delay_ms(1500);
		Window_Move(0);
	}
}


void Ir_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5;			
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(GPIOB, &GPIO_InitStructure);

}


//����
OS_STK User_TASK_STK[User_STK_SIZE];
void User_Task(void *pdata)
{	 	
	Log_Uartx("Task Of User Created...\n");
	while(1)
	{
		CAN_Send_Ch_Val(1,Lux_In);
		Delay_ms(10);	
		CAN_Send_Ch_Val(2,Lux_Out);
		Delay_ms(10);
		CAN_Send_Ch_Val(3,MHZ19_CO2);
		Delay_ms(1000);
	}
}









