#include "EXTI.h"



void My_EXTI_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	EXTI_InitTypeDef EXTI_InitStructure;
	NVIC_InitTypeDef NVIC_InitStructure;
	

	
	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_Code1|GPIO_Pin_Code2;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_Init(GPIO_Port_Code , &GPIO_InitStructure);
	

	GPIO_EXTILineConfig(GPIO_PortSourceEXTI_Code, GPIO_PinSourceEXTI_Code1);
	GPIO_EXTILineConfig(GPIO_PortSourceEXTI_Code, GPIO_PinSourceEXTI_Code2);
	
	
	
	EXTI_InitStructure.EXTI_Line = EXTI_LINE_Code1;
	EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
	EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising_Falling;
	EXTI_InitStructure.EXTI_LineCmd = ENABLE;
	EXTI_Init(&EXTI_InitStructure);
	
	EXTI_InitStructure.EXTI_Line = EXTI_LINE_Code2;
	EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
	EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising_Falling;
	EXTI_InitStructure.EXTI_LineCmd = ENABLE;
	EXTI_Init(&EXTI_InitStructure);
	
	
	NVIC_InitStructure.NVIC_IRQChannel = EXTI15_10_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);
}


signed short Code_Num=0;
void EXTI15_10_IRQHandler(void)
{
	OS_CPU_SR  cpu_sr;
	OS_ENTER_CRITICAL();                         /* Tell uC/OS-II that we are starting an ISR          */
	OSIntNesting++;
	OS_EXIT_CRITICAL();
	if(EXTI_GetITStatus(EXTI_LINE_Code1)!=RESET)
	{
		EXTI_ClearITPendingBit(EXTI_LINE_Code1);  //��� EXTI_LINE �ϵ��жϱ�־λ
		if(CodeA&&CodeB)
			Code_Num++;			
		else
			Code_Num--;	
	}
	else if(EXTI_GetITStatus(EXTI_LINE_Code2)!=RESET)
	{
		EXTI_ClearITPendingBit(EXTI_LINE_Code2);  //��� EXTI_LINE �ϵ��жϱ�־λ
		if( CodeA&&CodeB)
			Code_Num--;	
		else
			Code_Num++;		
	}
	OSIntExit();                                 /* Tell uC/OS-II that we are leaving the ISR          */	
}



















