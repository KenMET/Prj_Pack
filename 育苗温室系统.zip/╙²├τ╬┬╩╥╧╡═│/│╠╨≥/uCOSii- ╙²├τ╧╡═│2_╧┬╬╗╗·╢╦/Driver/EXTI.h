#ifndef _EXTI_H_
#define _EXTI_H_

//UCOSii�����ļ�����
#include "includes.h"

#include "stm32f10x.h"
#include "stm32f10x_exti.h"


#define GPIO_Pin_Ir	 							GPIO_Pin_5
#define GPIO_PinSourceEXTI_Ir 		GPIO_PinSource5
#define EXTI_LINE_Ir							EXTI_Line5
#define GPIO_PortSourceEXTI_Ir 		GPIO_PortSourceGPIOB
#define GPIO_Port_Ir  						GPIOB



#define GPIO_Pin_Code1	 						GPIO_Pin_14
#define GPIO_PinSourceEXTI_Code1 		GPIO_PinSource14
#define EXTI_LINE_Code1							EXTI_Line14
#define GPIO_Pin_Code2	 						GPIO_Pin_15
#define GPIO_PinSourceEXTI_Code2 		GPIO_PinSource15
#define EXTI_LINE_Code2							EXTI_Line15

#define GPIO_PortSourceEXTI_Code 		GPIO_PortSourceGPIOB
#define GPIO_Port_Code  						GPIOB

#define CodeA   PBin(15)  
#define CodeB   PBin(14)  



extern signed short Code_Num;

extern void My_EXTI_Init(void);


#endif
