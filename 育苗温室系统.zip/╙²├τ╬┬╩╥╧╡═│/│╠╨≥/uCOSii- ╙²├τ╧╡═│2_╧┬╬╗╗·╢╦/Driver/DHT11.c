#include "DHT11.h"



unsigned char DHT_Data[2]={0,0};

unsigned char DHT_Init(void)
{	 
 	GPIO_InitTypeDef  GPIO_InitStructure;
 	
 	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);	 //ʹ��PG�˿�ʱ��
	
 	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;				 //PG11�˿�����
 	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; 		 //�������
 	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
 	GPIO_Init(GPIOB, &GPIO_InitStructure);				 //��ʼ��IO��
 	
	DHT_SDA_Out = 1;		    
	
	DHT_Rst();  //��λDHT11
	return DHT_Check();//�ȴ�DHT11�Ļ�Ӧ
} 

//��λDHT
void DHT_Rst(void)	   
{                 
	DHT_SDA_OUT(); 	//SET OUTPUT
	DHT_SDA_Out=0; 	//����DQ
	Delay_ms(20);    	//��������18ms
	DHT_SDA_Out=1; 	//DQ=1 
	Delay_us(30);     	//��������20~40us
}

unsigned char DHT_Check(void) 	   
{   
	unsigned char retry=0;
	DHT_SDA_IN();//SET INPUT	 
  while (DHT_SDA_In&&retry<100)//DHT11������40~80us
	{
		retry++;
		Delay_us(1);
	}
	if(retry>=100)
		return 1;
	else 
		retry=0;
  while (!DHT_SDA_In&&retry<100)//DHT11���ͺ���ٴ�����40~80us
	{
		retry++;
		Delay_us(1);
	}
	if(retry>=100)return 1;	    
	return 0;
}


unsigned char DHT11_Read_Bit(void) 			 
{
 	unsigned char retry=0;
	while(DHT_SDA_In&&retry<100)//�ȴ���Ϊ�͵�ƽ
	{
		retry++;
		Delay_us(1);
	}
	retry=0;
	while(!DHT_SDA_In&&retry<100)//�ȴ���ߵ�ƽ
	{
		retry++;
		Delay_us(1);
	}
	Delay_us(40);//�ȴ�40us
	if(DHT_SDA_In)return 1;
	else return 0;		   
}
unsigned char Read_8Bit_DHT(void)    
{        
	unsigned char i,dat=0;
	for (i=0;i<8;i++) 
	{
		dat<<=1; 
		dat|=DHT11_Read_Bit();
	}						    
	return dat;
}


void Read_DHT(unsigned char *Dat)
{
 	unsigned char buf[5];
	unsigned char i;
	DHT_Rst();
	if(DHT_Check()==0)
	{
		for(i=0;i<5;i++)//��ȡ40λ����
		{
			buf[i]=Read_8Bit_DHT();
		}
		if((buf[0]+buf[1]+buf[2]+buf[3])==buf[4])
		{
			Dat[0]=buf[0];
			Dat[1]=buf[2];
		}
		else
			Log_Uartx("DHT Data Err...\n");
	}
	else 
		Log_Uartx("DHT Check Err...\n");
}


//DHT����
OS_STK DHT_TASK_STK[DHT_STK_SIZE];
void DHT_Task(void *pdata)
{	 	
	Log_Uartx("Task Of DHT Created...\n");
	while(1)
	{
		Delay_ms(5000);
		Read_DHT(DHT_Data);
		printf("Hum:%dRH   Tem:%d\n",DHT_Data[0],DHT_Data[1]);
	}
}



