#ifndef __Heat_H__
#define __Heat_H__

//UCOSii�����ļ�����
#include "includes.h"

#include "sys.h"
#include "stm32f10x.h"




#define Heat  		PAout(4)



extern void Heat_Init(void);

extern void Heat_On(void);
extern void Heat_Off(void);


#endif

		
