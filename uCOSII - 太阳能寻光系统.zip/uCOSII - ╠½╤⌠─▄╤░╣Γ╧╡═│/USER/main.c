#include "includes.h"
//�û�Driver
#include "led.h"
#include "Usart.h"
#include "DataScope_DP.h"
#include "EXTI.h"
#include "IIC_Direct.h"
#include "PWM.h"
#include "Catch_PWM.h"
#include "MPU6050.h"
#include "ADC.h"


signed int PWM_PID=0;
float err;

/////////////////////////UCOSII�����ջ����///////////////////////////////////
//START ����
//�����������ȼ�
#define START_TASK_PRIO      			10 //��ʼ��������ȼ�����Ϊ���
//���������ջ��С
#define START_STK_SIZE  				128
//���������ջ�ռ�	
OS_STK START_TASK_STK[START_STK_SIZE];   //typedef unsigned int   OS_STK;
//�������ӿ�
void start_task(void *pdata);	
 
//Test ����
//�����������ȼ�
#define Test_TASK_PRIO      			5 
//���������ջ��С
#define Test_STK_SIZE  				128
//���������ջ�ռ�	
OS_STK Test_TASK_STK[Test_STK_SIZE];  
//�������ӿ�
void Test_task(void *pdata)
{
	
	double Kp=5,Kd=-0.3;
	float Desiner=0;
	unsigned char Blank=220;
	unsigned int cnt=0;

	Usart1_SendString("Task_Test Activate Complete...\n");
	

	
	while(w_and_angle.angle_roll > 0.2 || w_and_angle.angle_roll < -0.2)
	{
		err = w_and_angle.angle_roll - Desiner;
		PWM_PID = err * Kp + w_and_angle.w_roll * Kd;
		if(err < 0)
			Motor2_PWM(Forward,-PWM_PID+Blank);
		else
			Motor2_PWM(Backward,PWM_PID+Blank);			
		Delay_ms(5);
	}
	Motor2_PWM(Backward,0);
	Delay_ms(5);
		
	TIM2->CNT = 0;

	
	while(1)
	{
		
		err = (signed int)AD_Data.AD_Data2 - (signed int)AD_Data.AD_Data5 + 500;
		if(err > 50 || err < -50)
		{
			PWM_PID = err * 0.2 ;
			if(err < 0)
				Motor1_PWM(Forward,-PWM_PID+250);
			else
				Motor1_PWM(Backward,PWM_PID+250);		
		}
		else  
			Motor1_PWM(Backward,0);			
/////////////////////////////////////////////////////////////////////////		
		err = (signed int)AD_Data.AD_Data4 - (signed int)AD_Data.AD_Data0;
		if(err > 40 || err < -40)
		{
			PWM_PID = err * 0.5 ;
			if(err < 0)
				Motor2_PWM(Forward,-PWM_PID+Blank);
			else
				Motor2_PWM(Backward,PWM_PID+Blank);		
		}
		else
			Motor2_PWM(Backward,0);	
		
	
		
/*////////////////////////////////////////////////////////		
		Encoder_angle = Encoder_Number1 / 8.666667f;
		err = Encoder_angle - Desiner;
		if(err > 1 || err < -1)
		{
			PWM_PID = err * Kp + w_and_angle.w_roll * Kd;
			if(err < 0)
				Motor2_PWM(Forward,-PWM_PID+Blank);
			else
				Motor2_PWM(Backward,PWM_PID+Blank);			
		}
		else
			Motor2_PWM(Backward,0);

///////////////////////////////////////////////////////////		
//		Encoder_angle = Encoder_Number2 / 8.666667f;

//		err = Encoder_angle - Desiner;
//		if(err > 1 || err < -1)
//		{
//			PWM_PID = err * 4 ;
//			if(err > 0)
//				Motor1_PWM(Forward,PWM_PID+250);
//			else
//				Motor1_PWM(Backward,-PWM_PID+250);			
//		}
//		else
//			Motor1_PWM(Backward,0);
		cnt++;
		if(cnt==500)
			Desiner = 70;
		else if(cnt==1000)
		{
			Desiner = -70;
			cnt = 0;
		}		
*/////////////////////////////////////////////////////////
//

		Delay_ms(5);
	}

}	


int main(void)
{
	Delay_init();	     //��ʱ��ʼ��	  
	NVIC_Configuration(); 	 //����NVIC�жϷ���2:2λ��ռ���ȼ���2λ��Ӧ���ȼ�
	Usart1_Init(115200);
	Usart1_SendString("Usart Init Complete...\n");

	LED_Init();		  	 //��ʼ����LED���ӵ�Ӳ���ӿ�
	Usart1_SendString("LED Init Complete...\n");
	
	TIM4_PWM_Init(1000,71);
	Usart1_SendString("PWM Init Complete...\n");
	
	TIM2_Cap_Init();
	TIM3_Cap_Init();
	Usart1_SendString("Encoder Init Complete...\n");
	
	IIC_Init();
	Usart1_SendString("I2C Init Complete...\n");
	MPU6050_Init();
	My_EXTI_Init();
	Usart1_SendString("MPU6050&EXTI Init Complete...\n");

	Adc_Init();
	Usart1_SendString("Adc Init Complete...\n");



	Usart1_SendString("System Activate Complete...\n");
	Usart1_SendString("Starting Task...\n");
	OSInit();   
	OSTaskCreate(start_task,(void *)0,(OS_STK *)&START_TASK_STK[START_STK_SIZE-1],START_TASK_PRIO );//������ʼ����
	OSStart();
}

 
	  
//��ʼ����
void start_task(void *pdata)
{
	OS_CPU_SR cpu_sr=0;     //typedef unsigned int  OS_CPU_SR;
	pdata = pdata; 
	OSStatInit();					  //��ʼ��ͳ������.�������ʱ1��������	
	OS_ENTER_CRITICAL();		//�����ٽ���(�޷����жϴ��)  


	
//	OSTaskCreate(Task_Usart1,(void *)0,(OS_STK*)&Usart1_TASK_STK[Usart1_STK_SIZE-1],Usart1_TASK_PRIO);						   
// 	OSTaskCreate(Task_Usart2,(void *)0,(OS_STK*)&Usart2_TASK_STK[Usart2_STK_SIZE-1],Usart2_TASK_PRIO);						   


	
	OSTaskCreate(Task_DataScope,(void *)0,(OS_STK*)&DataScope_TASK_STK[DataScope_STK_SIZE-1],DataScope_TASK_PRIO);						   
 
	OSTaskCreate(Catch_PWM_task,(void *)0,(OS_STK*)&Catch_PWM_TASK_STK[Catch_PWM_STK_SIZE-1],Catch_PWM_TASK_PRIO);						   	
	
	OSTaskCreate(led1_task,(void *)0,(OS_STK*)&LED1_TASK_STK[LED1_STK_SIZE-1],LED1_TASK_PRIO);						   

	OSTaskCreate(Test_task,(void *)0,(OS_STK*)&Test_TASK_STK[Test_STK_SIZE-1],Test_TASK_PRIO);	 				   

	OSTaskCreate(ADC_task,(void *)0,(OS_STK*)&ADC_TASK_STK[ADC_STK_SIZE-1],ADC_TASK_PRIO);	 				   


	OSTaskSuspend(START_TASK_PRIO);	//������ʼ����.
	OS_EXIT_CRITICAL();				//�˳��ٽ���(���Ա��жϴ��)
}























