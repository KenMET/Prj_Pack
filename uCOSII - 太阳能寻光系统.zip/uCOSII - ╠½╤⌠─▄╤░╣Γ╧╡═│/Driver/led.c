#include "led.h"

//uCOS
#include "ucos_ii.h"
#include "os_cpu.h"
#include "os_cfg.h"

OS_STK LED1_TASK_STK[LED1_STK_SIZE];




void LED_Init(void)
{

	GPIO_InitTypeDef GPIO_InitStructure_LED;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB|RCC_APB2Periph_GPIOD|RCC_APB2Periph_GPIOG, ENABLE);
	
	GPIO_InitStructure_LED.GPIO_Pin = GPIO_Pin_13;			
  GPIO_InitStructure_LED.GPIO_Mode = GPIO_Mode_Out_PP;
  GPIO_InitStructure_LED.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(GPIOD, &GPIO_InitStructure_LED);
	
	GPIO_InitStructure_LED.GPIO_Pin = GPIO_Pin_14;
	GPIO_Init(GPIOG, &GPIO_InitStructure_LED);
	
	GPIO_InitStructure_LED.GPIO_Pin = GPIO_Pin_13;
	GPIO_Init(GPIOB, &GPIO_InitStructure_LED);
	
	AD0 = 1;	//MPU6050��		
	
}


//LED1����
void led1_task(void *pdata)
{	 	
	Usart1_SendString("Task_LED Activate Complete...\n");
	while(1)
	{
		LED1=0;
		LED0=0;
		Delay_ms(201);
		LED0=1;
		Delay_ms(201);
		
		LED1=1;
		LED0=0;
		Delay_ms(201);
		LED0=1;
		Delay_ms(201);
	
	}
}



