#include "Delay_RTOS.h"





void Delay_ms(unsigned int Delay_T)
{
	portTickType x;
	x = xTaskGetTickCount();
	vTaskDelayUntil(&x,Delay_T);
}




void Delay_us(unsigned int Delay_T)
{
		unsigned char k;
		unsigned int Delay_Time;
		for(Delay_Time = Delay_T;Delay_Time>0;Delay_Time--)
				for(k=0;k<70;k++);
}

























