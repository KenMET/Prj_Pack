#ifndef __ESP8266_H_
#define __ESP8266_H_

#include"stm32f10x.h"
#include "usart.h"
#include "Flash.h"
#include "sys.h"

#define FLASH_SAVE_WIFI  0x0807e000		  //���ڴ�WIFI��Ϣ
#define FLASH_SAVE_Phone 0x0807f000		  //���ڴ����



extern void ESP8266_Init(void);
extern void ESP8266_Send(unsigned char *Words);

#endif
