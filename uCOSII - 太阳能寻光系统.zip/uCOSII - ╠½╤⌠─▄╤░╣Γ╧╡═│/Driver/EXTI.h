#ifndef _EXTI_H_
#define _EXTI_H_

#include "stm32f10x.h"
#include "stm32f10x_exti.h"
#include "Usart.h"

#include "MPU6050.h"

extern unsigned char EXTI_Flag;


#define GPIO_Pin_EXTI 					GPIO_Pin_12
#define GPIO_PinSourceEXTI 			GPIO_PinSource12
#define GPIO_Port_EXTI					GPIOB
#define GPIO_PortSourceEXTI 		GPIO_PortSourceGPIOB
#define EXTI_LINE 							EXTI_Line12
#define EXTIx_IRQn 							EXTI15_10_IRQn

extern void My_EXTI_Init(void);



#endif
