#ifndef __PWM_H_
#define __PWM_H_

#include "stm32f10x.h"
#include "stm32f10x_tim.h"
#include "Delay.h"

#include "MPU6050.h"

/*
���PWM4·���ֱ�ʹ��PD12��PD13��PD14��PD15
ռ�ձ���������
*/
#define Forward   1
#define Backward  0



extern unsigned int PWM1,PWM2,PWM3,PWM4;


extern void TIM4_PWM_Init(u16 arr,u16 psc);
extern void PWM_Ctrl_1(unsigned int zkb);
extern void PWM_Ctrl_2(unsigned int zkb);
extern void PWM_Ctrl_3(unsigned int zkb);
extern void PWM_Ctrl_4(unsigned int zkb);

extern void Motor1_PWM(unsigned char Way,unsigned int PWM_In);
extern void Motor2_PWM(unsigned char Way,unsigned int PWM_In);

#endif
