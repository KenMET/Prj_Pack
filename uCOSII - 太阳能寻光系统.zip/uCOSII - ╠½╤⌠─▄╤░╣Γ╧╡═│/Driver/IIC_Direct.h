#ifndef _IIC_Direct_H_
#define	_IIC_Direct_H_

#include "stm32f10x.h"
#include "stm32f10x_i2c.h"
#include "includes.h"


#define true 1
#define false 0 

#define TRUE  0
#define FALSE -1
#define  I2C_Direction_Transmitter      ((uint8_t)0x00)	//д
#define  I2C_Direction_Receiver         ((uint8_t)0x01)	//��

#define SDA_IN()  {GPIOB->CRH&=0XFFFF0FFF;GPIOB->CRH|=8<<12;} //PB11����ģʽ
#define SDA_OUT() {GPIOB->CRH&=0XFFFF0FFF;GPIOB->CRH|=3<<12;} //PB11���ģʽ

#define IIC_SCL    PBout(10) //SCL
#define IIC_SDA    PBout(11) //SDA
#define READ_SDA   PBin(11)  //����SDA 

#define RAD_TO_DEG 57.295779513082320876798154814105  // ����ת�Ƕȵ�ת����
#define DEG_TO_RAD 0.01745329251994329576923690768489 // �Ƕ�ת���ȵ�ת����

#ifndef M_PI
#define M_PI       3.14159265358979323846f
#endif /* M_PI */

#define RADX10 (M_PI / 1800.0f)                  // 0.001745329252f
#define RAD    (M_PI / 180.0f)

#define min(a, b) ((a) < (b) ? (a) : (b))
#define max(a, b) ((a) > (b) ? (a) : (b))
#define abs(x) ((x) > 0 ? (x) : -(x))
 
//IIC���в�������
extern void IIC_Start(void);
extern void IIC_Send_Byte(u8 txd);
extern u8 IIC_Read_Byte(void);
extern void IIC_Ack(void);
extern void IIC_NAck(void);
extern void IIC_Stop(void);
extern u8 IIC_Wait_Ack(void);
extern void IIC_Init(void);                					//��ʼ��IIC��IO��				 
extern u8 IIC_Write_Buffer(u8 addr, u8 reg, u8 len, u8 * data);
extern int IIC_Write(u8 addr, u8 reg, u8 len, u8* data);
extern u8 IIC_Read_Buffer(u8 addr, u8 reg, u8 len, u8* buf);
extern int IIC_Read(u8 addr, u8 reg, u8 len, u8 *buf);
extern u8 IIC_WriteOneByte(u8 addr, u8 reg, u8 data);
extern u16 IIC_GetErrorCounter(void);
extern void Single_WriteI2C(unsigned char REG_Address,unsigned char REG_data);
extern unsigned char Single_ReadI2C(unsigned char REG_Address);//��ȡ���ֽ�

#endif
