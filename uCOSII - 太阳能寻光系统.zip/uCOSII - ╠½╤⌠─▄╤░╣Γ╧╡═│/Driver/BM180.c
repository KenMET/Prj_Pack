#include "BM180.h"

OS_STK BM180_TASK_STK[BM180_STK_SIZE];

short AC1;
short AC2;
short AC3;
unsigned short AC4;
unsigned short AC5;
unsigned short AC6;
short B1;
short B2;
short MB;
short MC;
short MD;


unsigned char BMP180_ID=0;  //ID Of BMP180 
float True_Temp=0;       		//ʵ���¶�,��λ:��C
float True_Press=0;      		//ʵ����ѹ,��λ:Pa
float True_Altitude=0;   		//ʵ�ʸ߶�,��λ:m



unsigned char BMP180_Read_OneByte(u8 ReadAddr)
{
	unsigned char temp = 0;
	unsigned char IIC_ComFlag = 1;   
	 
	IIC_Start();    
	IIC_Send_Byte(BMP180_Addr); 
	IIC_ComFlag = IIC_Wait_Ack();  
	if (IIC_ComFlag == 0)                          
	{
		IIC_Send_Byte(ReadAddr);               
		IIC_Start();
		IIC_Send_Byte(BMP180_Addr|0x01);     
		temp = IIC_Read_Byte();                    
		IIC_NAck();                 
		IIC_Stop();
	}
	return (temp);      
}

short BMP180_Read_TwoByte(u8 ReadAddr)
{
    u8 IIC_ComFlag = 1;   
    u8 MSB,LSB;
    short temp;
     
    IIC_Start();
		IIC_Send_Byte(BMP180_Addr);
    IIC_ComFlag = IIC_Wait_Ack();
    if (IIC_ComFlag == 0)
    {
        IIC_Send_Byte(ReadAddr);
        IIC_Start();
        IIC_Send_Byte(BMP180_Addr|0x01);
        MSB = IIC_Read_Byte();      
        IIC_Ack();        
        LSB = IIC_Read_Byte();  
        IIC_NAck();        
        IIC_Stop();
    }
    temp = MSB*256+LSB;
    return temp;                                                    
}

void BMP180_Write_OneByte(u8 RegAdd, u8 Data)
{
    IIC_Start();                       //IIC start
    IIC_Send_Byte(BMP180_Addr);   //slave address+W:0
    IIC_Send_Byte(RegAdd);
    IIC_Send_Byte(Data);
    IIC_Stop(); 
}

void Read_CalibrationData(void)
{
    AC1 = BMP180_Read_TwoByte(0xaa);
    AC2 = BMP180_Read_TwoByte(0xac);
    AC3 = BMP180_Read_TwoByte(0xae);
    AC4 = BMP180_Read_TwoByte(0xb0);
    AC5 = BMP180_Read_TwoByte(0xb2);
    AC6 = BMP180_Read_TwoByte(0xb4);
    B1  = BMP180_Read_TwoByte(0xb6);
    B2  = BMP180_Read_TwoByte(0xb8);
    MB  = BMP180_Read_TwoByte(0xba);
    MC  = BMP180_Read_TwoByte(0xbc);
    MD  = BMP180_Read_TwoByte(0xbe);
}
//��ȡû�о����������¶�ֵ
long Get_BMP180UT(void)
{
    long UT;
    BMP180_Write_OneByte(BMP180_Reg_Addr,BMP180_Reg_Temperature);
    Delay_ms(10);                                   //wait 4.5ms
    UT = BMP180_Read_TwoByte(BMP180_ROM_MSB);        
    return UT;
}
//��ȡû�о���������ѹ��ֵ
long Get_BMP180UP(void)
{
    long UP=0;
    BMP180_Write_OneByte(BMP180_Reg_Addr,BMP180_Reg_Pressure0);     
    Delay_ms(10);                                
    UP = BMP180_Read_TwoByte(BMP180_ROM_MSB); 
    UP &= 0x0000FFFF;    
    return UP;      
}

//��δ�����������¶Ⱥ�ѹ��ֵת��Ϊʵ��ֵ
void Convert_UncompensatedToTrue(long UT,long UP)
{
    long X1,X2,X3,B3,B5,B6,B7,T,P;
    unsigned long B4;
     
    X1 = ((UT-AC6)*AC5)>>15;     
    X2 = ((long)MC<<11)/(X1+MD);  
    B5 = X1+X2;                
    T = (B5+8)>>4;                   
    True_Temp = T/10.0;           
 
    B6 = B5-4000;                  
    X1 = (B2*B6*B6)>>23;             
    X2 = (AC2*B6)>>11;               
    X3 = X1+X2;                      
    B3 = (((long)AC1*4+X3)+2)/4;   
    X1 = (AC3*B6)>>13;               
    X2 = (B1*(B6*B6>>12))>>16;   
    X3 = ((X1+X2)+2)>>2;           
    B4 = AC4*(unsigned long)(X3+32768)>>15;  
    B7 = ((unsigned long)UP-B3)*50000;        
    if (B7 < 0x80000000)
			P = (B7*2)/B4;  
    else 
			P=(B7/B4)*2;                 
    X1 = (P/256.0)*(P/256.0);     
    X1 = (X1*3038)>>16;            
    X2 = (-7357*P)>>16;            
    P = P+((X1+X2+3791)>>4);   
    True_Press = P;            
    True_Altitude = 44330*(1-pow((P/101325.0),(1.0/5.255)));            
}



///////////////RTOS//////////////////////////
void BM180_task(void *pdata)
{
	long UT,UP;
   
	while(1)
	{
		UT = Get_BMP180UT();           
		UP = Get_BMP180UP();
		Convert_UncompensatedToTrue(UT,UP);
		Delay_ms(800);
	}
}






















