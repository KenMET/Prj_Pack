#ifndef __PID_H
#define __PID_H


typedef struct {
	float epsilon;
	float MAX;
	float MIN;
	float Kp;
	float Ki;
	float Kd;
	float dt;
	float pre_error;
	float integral;
}PID_Struct;

extern void PidInit(PID_Struct * pid, float p, float i, float d);
extern float PidCalc(PID_Struct * pid, float setpoint, float input);



	
#endif //__PID_H
