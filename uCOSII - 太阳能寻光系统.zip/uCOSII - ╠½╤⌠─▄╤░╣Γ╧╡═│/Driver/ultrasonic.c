#include "ultrasonic.h"

#define  KALMAN_Q	 3 * 16  // 0.1         //0.5
#define  KALMAN_R  18 * 16  //	10          //5

unsigned int Ultrasonic_Distance;      //����(mm)

unsigned char Get_Distance[1]={0x55};
unsigned char V_Usart[4]={0,0,0,0};
unsigned int Ultrasonic_Distance_SUM[10] ; 

void Ultrasonic_StartMeasure(void)
{
	TRIG_Pout = 1;
	Delay_us(20);
	TRIG_Pout = 0;
}


unsigned int KalmanFilter_x(const unsigned int ResrcData,
				double ProcessNiose_Q,double MeasureNoise_R,double InitialPrediction)
{
		double R = MeasureNoise_R;
		double Q = ProcessNiose_Q;

		static  double x_last;

		double x_mid = x_last;
		double x_now;

		static   double p_last;

		double p_mid ;
		double p_now;
		double kg;      

		x_mid=x_last; //x_last=x(k-1|k-1),x_mid=x(k|k-1)
		p_mid=p_last+Q; //p_mid=p(k|k-1),p_last=p(k-1|k-1),Q=����
		kg=p_mid/(p_mid+R); //kg?kalman filter,RΪ����
		x_now=x_mid+kg*(ResrcData-x_mid);//���Ƴ�����ֵ
		 

		p_now=(1-kg)*p_mid;//����ֵ��Ӧ��covariance 


		p_last = p_now; //����covariance
		x_last = x_now; //����ϵͳ״ֵ̬

		return x_now;               
}


//Ultrasonic����
OS_STK Ultrasonic_TASK_STK[Ultrasonic_STK_SIZE];
void Ultrasonic_task(void *pdata)
{	 	
	
	while(1)
	{
		Usart1_SendString(Get_Distance);
		Delay_ms(50);
		Ultrasonic_Distance = Got_Usart1_Data[0]*256 + Got_Usart1_Data[1];
		
		Ultrasonic_Distance  = KalmanFilter_x( Ultrasonic_Distance , KALMAN_Q, KALMAN_R, 60 );			
		
		V_Usart[0] = (Ultrasonic_Distance % 10000) /1000 + 48;
		V_Usart[1] = (Ultrasonic_Distance % 1000) /100 + 48;
		V_Usart[2] = (Ultrasonic_Distance % 100) /10 + 48;
		V_Usart[3] =  Ultrasonic_Distance % 10 + 48;
		Usart2_SendString("Distance:  ");
		Usart2_SendString(V_Usart);
		Usart2_SendString(" mm\n");
		
		Usart1_Situation=0;
		Usart1_Finish=0;
		Clean_Str(Got_Usart1_Data);
	}
}













