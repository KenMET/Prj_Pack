#include "MPU6050.h"

//���岻ͬ������Χ�Ŀ̶�����
#define Gyro_250_Scale_Factor   131.0f
#define Gyro_500_Scale_Factor   65.5f
#define Gyro_1000_Scale_Factor  32.8f
#define Gyro_2000_Scale_Factor  16.4f
#define Accel_2_Scale_Factor    16384.0f
#define Accel_4_Scale_Factor    8192.0f
#define Accel_8_Scale_Factor    4096.0f
#define Accel_16_Scale_Factor   2048.0f
#define DEFAULT_MPU_HZ 200

W_AND_ANGLE w_and_angle;

static signed char gyro_orientation[9] = {-1, 0, 0,
                                           0,-1, 0,
                                           0, 0, 1};//roll��pitch���Ƿ��ģ�yaw������

double q0=1.0f,q1=0.0f,q2=0.0f,q3=0.0f;																				 

unsigned long sensor_timestamp;
short gyro[3], accel[3], sensors;
unsigned char more;
long quat[4];


static  unsigned short inv_row_2_scale(const signed char *row)
{
    unsigned short b;

    if (row[0] > 0)
        b = 0;
    else if (row[0] < 0)
        b = 4;
    else if (row[1] > 0)
        b = 1;
    else if (row[1] < 0)
        b = 5;
    else if (row[2] > 0)
        b = 2;
    else if (row[2] < 0)
        b = 6;
    else
        b = 7;      // error
    return b;
}

static  unsigned short inv_orientation_matrix_to_scalar(
    const signed char *mtx)
{
    unsigned short scalar;

    /*
       XYZ  010_001_000 Identity Matrix
       XZY  001_010_000
       YXZ  010_000_001
       YZX  000_010_001
       ZXY  001_000_010
       ZYX  000_001_010
     */

    scalar = inv_row_2_scale(mtx);
    scalar |= inv_row_2_scale(mtx + 3) << 3;
    scalar |= inv_row_2_scale(mtx + 6) << 6;


    return scalar;
}

static void run_self_test(void)
{
	
    int result;
    long gyro[3], accel[3];

    result = mpu_run_self_test(gyro, accel);
    if (result == 0x7) {
        /* Test passed. We can trust the gyro data here, so let's push it down
         * to the DMP.
         */
        float sens;
        unsigned short accel_sens;
        mpu_get_gyro_sens(&sens);
        gyro[0] = (long)(gyro[0] * sens);
        gyro[1] = (long)(gyro[1] * sens);
        gyro[2] = (long)(gyro[2] * sens);
        dmp_set_gyro_bias(gyro);
        mpu_get_accel_sens(&accel_sens);
        accel[0] *= accel_sens;
        accel[1] *= accel_sens;
        accel[2] *= accel_sens;
        dmp_set_accel_bias(accel);
		//printf("setting bias succesfully ......\r\n");
    }
	else
	{
		//printf("bias has not been modified ......\r\n");
	}

}

//����MPU6050�ĳ�ʼ��
void MPU6050_Init(void)
{
	int result=1;
	while(result)
	{
		result=mpu_init(); //��ʼ��MPU6050
		//st.chip_cfg.sample_rate�����ڴ˴��������趨
		//st.chip_cfg�ṹ���ڴ˴������˳�ʼ��
	}
	if(!result)
	{	 		 
	
		Usart1_SendString("mpu initialization complete......\n ");		//mpu initialization complete	 	  

		if(!mpu_set_sensors(INV_XYZ_GYRO | INV_XYZ_ACCEL))		//mpu_set_sensor
			Usart1_SendString("mpu_set_sensor complete ......\n");
		else
			Usart1_SendString("mpu_set_sensor come across error ......\n");

		if(!mpu_configure_fifo(INV_XYZ_GYRO | INV_XYZ_ACCEL))	//mpu_configure_fifo
			Usart1_SendString("mpu_configure_fifo complete ......\n");
		else
			Usart1_SendString("mpu_configure_fifo come across error ......\n");

		if(!mpu_set_sample_rate(DEFAULT_MPU_HZ))	   	  		//mpu_set_sample_rate
		//st.chip_cfg.sample_rate�����ڴ˴������˸ı䡣
		 Usart1_SendString("mpu_set_sample_rate complete ......\n");
		else
		 	Usart1_SendString("mpu_set_sample_rate error ......\n");

		if(!dmp_load_motion_driver_firmware())   	  			//dmp_load_motion_driver_firmvare
			Usart1_SendString("dmp_load_motion_driver_firmware complete ......\n");
		else
			Usart1_SendString("dmp_load_motion_driver_firmware come across error ......\n");

		if(!dmp_set_orientation(inv_orientation_matrix_to_scalar(gyro_orientation))) 	  //dmp_set_orientation
		 	Usart1_SendString("dmp_set_orientation complete ......\n");
		else
		 	Usart1_SendString("dmp_set_orientation come across error ......\n");

		if(!dmp_enable_feature(DMP_FEATURE_6X_LP_QUAT | DMP_FEATURE_TAP |
		    DMP_FEATURE_ANDROID_ORIENT | DMP_FEATURE_SEND_RAW_ACCEL | DMP_FEATURE_SEND_CAL_GYRO |
		    DMP_FEATURE_GYRO_CAL))		   	 					 //dmp_enable_feature
		 	Usart1_SendString("dmp_enable_feature complete ......\n");
		else
		 	Usart1_SendString("dmp_enable_feature come across error ......\n");

		if(!dmp_set_fifo_rate(DEFAULT_MPU_HZ))   	 			 //dmp_set_fifo_rate
		 	Usart1_SendString("dmp_set_fifo_rate complete ......\n");
		else
		 	Usart1_SendString("dmp_set_fifo_rate come across error ......\n");

		run_self_test();		//�Լ�

		if(!mpu_set_dmp_state(1))
		 	Usart1_SendString("mpu_set_dmp_state complete ......\n");
		else
		 	Usart1_SendString("mpu_set_dmp_state come across error ......\n");
	}
}

#define  KALMAN_Q	 0.2 * 16  // 0.1         //0.5
#define  KALMAN_R  18 * 16  //	10          //5
double KalmanFilter_x(const double ResrcData,
				double ProcessNiose_Q,double MeasureNoise_R,double InitialPrediction)
{
        double R = MeasureNoise_R;
        double Q = ProcessNiose_Q;

        static  double x_last;

        double x_mid = x_last;
        double x_now;

        static   double p_last;

        double p_mid ;
        double p_now;
        double kg;      

        x_mid=x_last; //x_last=x(k-1|k-1),x_mid=x(k|k-1)
        p_mid=p_last+Q; //p_mid=p(k|k-1),p_last=p(k-1|k-1),Q=����
        kg=p_mid/(p_mid+R); //kg?kalman filter,RΪ����
        x_now=x_mid+kg*(ResrcData-x_mid);//���Ƴ�����ֵ
         
  
        p_now=(1-kg)*p_mid;//����ֵ��Ӧ��covariance 


        p_last = p_now; //����covariance
        x_last = x_now; //����ϵͳ״ֵ̬

        return x_now;               
}

//�˺������Ƕ�ȡ6050���ݵĲ�������
void MPU6050_Pose(void)
{	
	double Pitch,Roll,Yaw;
	double Gyrox,Gyroy,Gyroz;	
	dmp_read_fifo(gyro, accel, quat, &sensor_timestamp, &sensors, &more);	 

	if(sensors & INV_WXYZ_QUAT )
	{

		q0 = (double)quat[0] / q30;	
		q1 = (double)quat[1] / q30;
		q2 = (double)quat[2] / q30;
		q3 = (double)quat[3] / q30;
  
		Pitch = asin(2 * q1 * q3 - 2 * q0* q2)* RAD_TO_DEG;	// pitch,��λ����	
		Roll  = -atan2(2 * q2 * q3 + 2 * q0 * q1, -2 * q1 * q1 - 2 * q2* q2 + 1)* RAD_TO_DEG;	// roll
		Yaw   = atan2(2*(q1*q2 + q0*q3),q0*q0+q1*q1-q2*q2-q3*q3) * RAD_TO_DEG;	//yaw	,��λ����

	  w_and_angle.angle_roll = Roll; 		//����Ƕ�
		w_and_angle.angle_pitch = Pitch;	//�����Ƕ�
		w_and_angle.angle_yaw = Yaw; // ת��Ϊ0~360��	//ƫ���Ƕ�
		
		Gyrox = gyro[0]/(double)Gyro_2000_Scale_Factor;
		Gyroy = gyro[1]/(double)Gyro_2000_Scale_Factor;
		Gyroz = gyro[2]/(double)Gyro_2000_Scale_Factor;
	
		Gyrox  = KalmanFilter_x( Gyrox , KALMAN_Q, KALMAN_R, 30 );

		
		w_and_angle.w_roll 	= Gyrox;
		w_and_angle.w_pitch = Gyroy;
		w_and_angle.w_yaw		= Gyroz;
		
	}		
}










