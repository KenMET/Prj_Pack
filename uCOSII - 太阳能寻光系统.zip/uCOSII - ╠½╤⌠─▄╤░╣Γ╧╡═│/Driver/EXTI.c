#include "EXTI.h"



void My_EXTI_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	EXTI_InitTypeDef EXTI_InitStructure;
	NVIC_InitTypeDef NVIC_InitStructure;
	/* ʹ��EXIT 4ͨ��*/	
	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_EXTI;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIO_Port_EXTI , &GPIO_InitStructure);
	
	GPIO_EXTILineConfig(GPIO_PortSourceEXTI , GPIO_PinSourceEXTI);
	
	EXTI_InitStructure.EXTI_Line = EXTI_LINE;
	EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
	EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising_Falling;
	EXTI_InitStructure.EXTI_LineCmd = ENABLE;
	EXTI_Init(&EXTI_InitStructure);
	EXTI_ClearITPendingBit(EXTI_LINE);
	
	NVIC_InitStructure.NVIC_IRQChannel = EXTIx_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 2;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 3;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure); 

}



void EXTI15_10_IRQHandler(void)
{
	OS_CPU_SR  cpu_sr;
	OS_ENTER_CRITICAL();                         /* Tell uC/OS-II that we are starting an ISR          */
	OSIntNesting++;
	OS_EXIT_CRITICAL();
	
	if(EXTI_GetITStatus(EXTI_Line12)!=RESET)//�ж�4���ϵ��ж��Ƿ���
	{		
		
		EXTI_ClearITPendingBit(EXTI_Line12);  //��� LINE4 �ϵ��жϱ�־λ
		MPU6050_Pose();
		
	} 	
	OSIntExit();                                 /* Tell uC/OS-II that we are leaving the ISR          */
}


void EXTI9_5_IRQHandler(void)
{
	OS_CPU_SR  cpu_sr;
	OS_ENTER_CRITICAL();                         /* Tell uC/OS-II that we are starting an ISR          */
	OSIntNesting++;
	OS_EXIT_CRITICAL();
	
	if(EXTI_GetITStatus(EXTI_Line8)!=RESET)//�ж�8���ϵ��ж��Ƿ���
	{			
		
		EXTI_ClearITPendingBit(EXTI_Line8);  //��� LINE8 �ϵ��жϱ�־λ

		
	} 	
	OSIntExit();                                 /* Tell uC/OS-II that we are leaving the ISR          */	
}
























