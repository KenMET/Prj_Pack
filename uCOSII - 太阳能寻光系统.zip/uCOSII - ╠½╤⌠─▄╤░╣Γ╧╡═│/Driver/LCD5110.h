#ifndef __LCD5110_H_
#define __LCD5110_H_

#include"stm32f10x.h"
#include "Delay.h"
#include "sys.h"

/*************������ʹ�õ�IO��**************/
#define RCC_LCD5110 	RCC_APB2Periph_GPIOB	
#define GPIO_LCD5110 	GPIOB


#define SCLK 	PBout(9)
#define SDIN 	PBout(8)
#define LCD_DC 	PBout(7)
#define LCD_CE 	PBout(6)
#define LCD_RST PBout(5) 

extern void GPIO_Configuration_LCD(void);
extern void LCD_init(void);
extern void LCD_clear(void);
extern void LCD_Write_String(unsigned char X,unsigned char Y,unsigned char *s);
extern void LCD_Write_Int(unsigned char X,unsigned char Y,int NUM);
extern void LCD_Write_Natural_Int(unsigned char X,unsigned char Y,int NUM);

#endif
