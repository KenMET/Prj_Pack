#ifndef __BM180_H__
#define __BM180_H__

#include "sys.h"
#include "math.h"
#include "stm32f10x.h"
#include "IIC_Direct.h"

//uCOS
#include "ucos_ii.h"
#include "os_cpu.h"
#include "os_cfg.h"

#include "Delay.h"

#define BMP180_Addr 							0xee
#define BMP180_Reg_Addr 					0xf4
#define BMP180_Reg_Temperature 		0x2e					
#define BMP180_Reg_Pressure0			0X34
#define BMP180_Reg_Pressure1			0X74
#define BMP180_Reg_Pressure2			0Xb4
#define BMP180_Reg_Pressure3			0Xf4

#define BMP180_ROM_MSB 						0xf6					//��ȡ��ַ
#define BMP180_ROM_LSB 						0xf7					//��ȡ��ַ


extern unsigned char BMP180_ID;          //ID Of BMP180 
extern float True_Temp;       //ʵ���¶�,��λ:��C
extern float True_Press;      //ʵ����ѹ,��λ:Pa
extern float True_Altitude;   //ʵ�ʸ߶�,��λ:m

extern void Convert_UncompensatedToTrue(long UT,long UP);
extern long Get_BMP180UP(void);
extern long Get_BMP180UT(void);
extern void Read_CalibrationData(void);
extern unsigned char BMP180_Read_OneByte(u8 ReadAddr);
extern short BMP180_Read_TwoByte(u8 ReadAddr);
extern void BMP180_Write_OneByte(u8 RegAdd, u8 Data);


///////////////RTOS//////////////////////////
//BM180����
//�����������ȼ�
#define BM180_TASK_PRIO       			7 
//���������ջ��С
#define BM180_STK_SIZE  		    		64
//���������ջ�ռ�	
extern OS_STK BM180_TASK_STK[BM180_STK_SIZE];

extern void BM180_task(void *pdata);




#endif

