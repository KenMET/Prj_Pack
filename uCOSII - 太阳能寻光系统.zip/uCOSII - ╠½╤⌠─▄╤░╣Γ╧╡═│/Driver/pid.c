#include "pid.h"
#include <math.h>





void PidInit(PID_Struct * pid, float p, float i, float d)	   
{
	pid->epsilon = 0.1;
	pid->MAX = 779;
	pid->MIN = 0;
	pid->Kp = p;
	pid->Ki = i;
	pid->Kd = d;
	pid->dt = 1;
	pid->pre_error = 0;
	pid->integral = 0;
}


float PidCalc(PID_Struct * pid, float setpoint, float input)
{
	float error, derivative, output;

	error = setpoint - input;
	pid->integral += error * pid->dt;				//����
	if( pid->integral > 500 )		//�����޷�
	  pid->integral = 500;
	if( pid->integral < -500 )
	  pid->integral = -500;
	derivative = (error - pid->pre_error) * pid->dt;	//΢��
	output = pid->Kp * error							//������
		   + pid->Ki * pid->integral 					//������
		   + pid->Kd * derivative;						//΢����
	pid->pre_error = error;
	return output;
}






