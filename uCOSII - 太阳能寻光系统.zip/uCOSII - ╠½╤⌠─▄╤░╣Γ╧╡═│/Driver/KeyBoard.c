#include "KeyBoard.h"
#include "Delay.h"

u8 Key;



void KeyBoard_Init()
{
	GPIO_InitTypeDef GPIO_InitStructure_KeyBoard;
	RCC_APB2PeriphClockCmd(RCC_Key,ENABLE);	 //��APB2�����ϵ�GPIOʱ��
/**************PA8~PA11(L)�ڶ���************/	
	GPIO_InitStructure_KeyBoard.GPIO_Pin = PIN_Key_L;
	GPIO_InitStructure_KeyBoard.GPIO_Speed = GPIO_Speed_50MHz;		  
	GPIO_InitStructure_KeyBoard.GPIO_Mode = GPIO_Mode_IPD;		  //PA0~PA3��������
	GPIO_Init(GPIO_Key, &GPIO_InitStructure_KeyBoard);	 	  		  //��ʼ��

/**************PA12~PA15(H)�ڶ���************/	
	GPIO_InitStructure_KeyBoard.GPIO_Pin = PIN_Key_H;
	GPIO_InitStructure_KeyBoard.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure_KeyBoard.GPIO_Mode = GPIO_Mode_Out_PP;	  //PA4~PA7�������
	GPIO_Init(GPIO_Key, &GPIO_InitStructure_KeyBoard);	 			  //��ʼ��
}



unsigned char real_key(unsigned char KEY)			   //��Ƭ��������//��ɫһ�߿�0��
{
	switch (KEY)
	{
	case(0) : return 3;
	case(1) : return 13;
	case(2) : return 14;
	case(3) : return 0;
	case(4) : return 12;
	case(5) : return 9;
	case(6) : return 8;
	case(7) : return 11;
	case(8) : return 6;
	case(9) : return 5;
	case(10) : return 1;
	case(11) : return 15;
	case(12) : return 7;
	case(13) : return 4;
	case(14) : return 10;
	case(15) : return 2;
	default:	return 16;
	}
}





void KeyScan(void)
{
	char flag=0;
	GPIO_Write(GPIO_Key,0xf0);
	Delay_ms(10);
	if(GPIO_Key->IDR&0x0f==0x00)	  //˵��û�м�����
	{										         
		flag=0;
		Key = 16;		
	}
	else 
	{
		Delay_ms(5);    //��ʱ5msȥ������
		if((GPIO_Key->IDR&0x0f)==0x00)
		{
			Key = 16;
			flag=0;
		}  
		else
			flag=1;				 //�м�����					
	}
	if(flag)
	{
		GPIO_Write(GPIO_Key,0x10);

			Delay_ms(10);
				switch(GPIO_Key->IDR&0x0f)
				{
					case(0X01):Key=1;break;
					case(0X02):Key=2;break;
					case(0X04):Key=3;break;
					case(0X08):Key=11;break;
				}
//			while((GPIO_Key->IDR&0x0f)!=0x00);	 //�ȴ��ɿ�
				
		GPIO_Write(GPIO_Key,0x20);
			Delay_ms(10);
				switch(GPIO_Key->IDR&0x0f)
				{
					case(0X01):Key=4;break;
					case(0X02):Key=5;break;
					case(0X04):Key=6;break;
					case(0X08):Key=12;break;
				}
//			while((GPIO_Key->IDR&0x0f)!=0x00);	 //�ȴ��ɿ�

		GPIO_Write(GPIO_Key,0x40);
			Delay_ms(10);
				switch(GPIO_Key->IDR&0x0f)
				{
					case(0X01):Key=7;break;
					case(0X02):Key=8;break;
					case(0X04):Key=9;break;
					case(0X08):Key=13;break;
				}
//			while((GPIO_Key->IDR&0x0f)!=0x00);	 //�ȴ��ɿ�

		 GPIO_Write(GPIO_Key,0x80);
		 	Delay_ms(10);
				switch(GPIO_Key->IDR&0x0f)
				{
					case(0X01):	Key=14;break;	 
					case(0X02):	Key=0;break;
					case(0X04): Key=15;break;
					case(0X08):	Key=10;break;
				}
//		   while((GPIO_Key->IDR&0x0f)!=0x00);	 //�ȴ��ɿ�
	}
	Key = real_key(Key);
}





































