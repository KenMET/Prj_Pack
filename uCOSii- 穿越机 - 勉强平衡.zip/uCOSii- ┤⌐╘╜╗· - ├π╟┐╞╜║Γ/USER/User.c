#include "User.h"

uint16_t Rocker_VAL[4]={2048,4095,2048,2048};		//ҡ��
int16_t PID_VAL[5];			//PID
int8_t PreP[7];					//Ԥ��λ
int8_t OFF_VAL[4];				//��ƫ����


int8_t Key=0,PID_Flag=0,OFF_Flag=0;



float PID_Roll_Out;
float PID_Pitch_Out;
float PID_Yaw_Out;
/*
1.������Դ��Ȱ���
2.ҡ���������Ǽ�С��������������
3.����������Roll����ǰ��Pitch����
*/
void Updata_PWM(uint16_t *Rocker)
{
	uint16_t PWM_T;
	float Desire_W_roll = 0,Desire_W_pitch = 0;
	
	
	PWM_T = 4096 - Rocker[1];
	PWM_T *= 1.7;
	Desire_angle_pitch = Rocker[2] - 2048;
	Desire_angle_roll  = Rocker[3] - 2048;
	Desire_angle_pitch /= 68.266667;
	Desire_angle_roll  /= 68.266667;		//2048/30��
	
	Desire_angle_pitch = -Desire_angle_pitch;	//	��Ҫȡ��һ�£���Ϊҡ����ǰ����������ġ�
	

	
	
	Desire_W_roll  = PidCalc(&PID_Roll,Desire_angle_roll,w_and_angle.angle_roll);
	Desire_W_pitch = PidCalc(&PID_Pitch,Desire_angle_pitch,w_and_angle.angle_pitch);
//	Desire_W_roll  = (Desire_angle_roll  - w_and_angle.angle_roll)  * 0.1;
//	Desire_W_pitch = (Desire_angle_pitch - w_and_angle.angle_pitch) * 0.1;
	PID_Roll_Out   = PidCalc(&PID_Roll_a,Desire_W_roll,w_and_angle.w_roll);
	PID_Pitch_Out  = PidCalc(&PID_Pitch_a,Desire_W_pitch,w_and_angle.w_pitch);
	
	
	if(     PID_Roll_Out  >  10000)			PID_Roll_Out  =  10000;
	else if(PID_Roll_Out  < -10000)			PID_Roll_Out  = -10000;
	if(     PID_Pitch_Out >  10000)			PID_Pitch_Out =  10000;
	else if(PID_Pitch_Out < -10000)			PID_Pitch_Out = -10000;

	Watch1 = PID_Roll_Out;
	Watch2 = PID_Pitch_Out;
//	printf("R:%.2f  P:%.2f\n",Watch1,Watch2);
	
	PWM1 = PWM_T+( 0 + PID_Pitch_Out - PID_Roll_Out) ;	
	PWM2 = PWM_T+( 0 + PID_Pitch_Out + PID_Roll_Out) ;	 	
	PWM3 = PWM_T+( 0 - PID_Pitch_Out + PID_Roll_Out) ;	
	PWM4 = PWM_T+( 0 - PID_Pitch_Out - PID_Roll_Out) ;	
	
	//�ٶȷ�Χ����
	if(PWM1 > 10000)					PWM1 = 10000;
	else if(PWM1 < 10)				PWM1 = 0;
	if(PWM2 > 10000)					PWM2 = 10000;
	else if(PWM2 < 10)				PWM2 = 0;
	if(PWM3 > 10000)					PWM3 = 10000;
	else if(PWM3 < 10)				PWM3 = 0;
	if(PWM4 > 10000)					PWM4 = 10000;
	else if(PWM4 < 10)				PWM4 = 0;
	
	
	if(Fly_Lock == 0 && PWM_T > 300)
	{
		PWM_Ctrl_1(Lowest + PWM1);
		PWM_Ctrl_2(Lowest + PWM2);
		PWM_Ctrl_3(Lowest + PWM3);
		PWM_Ctrl_4(Lowest + PWM4);		
	}
	else 
	{
		PWM_Ctrl_1(Lowest);
		PWM_Ctrl_2(Lowest);
		PWM_Ctrl_3(Lowest);
		PWM_Ctrl_4(Lowest);	
	}
}





//User����
OS_STK User_TASK_STK[User_STK_SIZE];
void User_Task(void *pdata)
{	 	
	float P,I,D;
	Log_Uartx("Task Of User Created...\n");
	while(1)
	{
		if(PID_Flag == 1)
		{
			P = PID_VAL[0];
			I = PID_VAL[1];
			D = PID_VAL[2];
			P /= 1000;
			I /= 1000;
			D /= 1000;
			
			switch(PID_VAL[3])
			{
				case 1:{
					PidInit(&PID_Roll,P,I,D);
					PidInit(&PID_Pitch,P,I,D);
					printf("A  P:%.2f  I:%.2f  D:%.2f\n",P,I,D);
				}break;
				case 3:{
					PidInit(&PID_Roll_a,P,I,D);
					PidInit(&PID_Pitch_a,P,I,D);
					printf("P:%.2f  I:%.2f  D:%.2f\n",P,I,D);
				}break;
			}
			PID_Flag = 0;
		}
		else if(OFF_Flag == 1)
		{
			roll_angel_offset = OFF_VAL[0];
			pitch_angel_offset= OFF_VAL[1];
			roll_angel_offset /= 10;
			pitch_angel_offset /= 10;
			Watch1 = roll_angel_offset;
			Watch2 = pitch_angel_offset;
			OFF_Flag = 0;
		}
		Delay_ms(100);
	}
}



















