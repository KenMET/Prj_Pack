#include "pid.h"



PID_Struct PID_Roll;
PID_Struct PID_Roll_a;
PID_Struct PID_Pitch;
PID_Struct PID_Pitch_a;

float PID_ABS(float Num)
{
	if(Num < 0)
		return -Num;
	return Num;
}

void PidInit(PID_Struct * pid, float p, float i, float d)	   
{
	pid->epsilon = 0.1;
	pid->MAX = 10000;
	pid->MIN = -10000;
	pid->Kp = p;
	pid->Ki = i;
	pid->Kd = d;
	pid->dt = 1;
	pid->pre_error = 0;
	pid->integral = 0;
}
float FABSF(float x)
{
	if(x < 0)
	x = -1*x;
	return x;
}
float PidCalc(PID_Struct * pid, float setpoint, float input)
{
	float error, derivative, output;

	error = setpoint - input;

	if (PID_ABS(error) > pid->epsilon)
		pid->integral += error * pid->dt;				//����
	derivative = (error - pid->pre_error) / pid->dt;	//΢��
	output = pid->Kp * error							//������
		   + pid->Ki * pid->integral 					//������
		   + pid->Kd * derivative;						//΢����
	if (output > pid->MAX)								
		output = pid->MAX;								//�������ֵ
	else if (output < pid->MIN)							
		output = pid->MIN;								//������Сֵ
	pid->pre_error = error;
	
	return output;
}
