#include "EXTI.h"


void My_EXTI_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	EXTI_InitTypeDef EXTI_InitStructure;
	NVIC_InitTypeDef NVIC_InitStructure;
	
	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_MPU;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIO_Port_MPU , &GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_SPI2;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIO_Port_SPI2 , &GPIO_InitStructure);
	
	GPIO_EXTILineConfig(GPIO_PortSourceEXTI_MPU , GPIO_PinSourceEXTI_MPU);
	GPIO_EXTILineConfig(GPIO_PortSourceEXTI_SPI2, GPIO_PinSourceEXTI_SPI2);
	
	EXTI_InitStructure.EXTI_Line = EXTI_LINE_MPU;
	EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
	EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling;
	EXTI_InitStructure.EXTI_LineCmd = ENABLE;
	EXTI_Init(&EXTI_InitStructure);
	
	EXTI_InitStructure.EXTI_Line = EXTI_LINE_SPI2;
	EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
	EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising_Falling;
	EXTI_InitStructure.EXTI_LineCmd = ENABLE;
	EXTI_Init(&EXTI_InitStructure);

	/* ʹ��EXIT 5-9ͨ�� */
	NVIC_InitStructure.NVIC_IRQChannel = EXTI9_5_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);
}



void EXTI9_5_IRQHandler(void)
{
	OS_CPU_SR  cpu_sr;
	OS_ENTER_CRITICAL();                         /* Tell uC/OS-II that we are starting an ISR          */
	OSIntNesting++;
	OS_EXIT_CRITICAL();
	if(EXTI_GetITStatus(EXTI_LINE_MPU)!=RESET)//�ж�MPU_IRQ���ϵ��ж��Ƿ���
	{		
		EXTI_ClearITPendingBit(EXTI_LINE_MPU);  //��� EXTI_LINE_MPU �ϵ��жϱ�־λ
		MPU6050_Pose();
	} 	
	if(EXTI_GetITStatus(EXTI_LINE_SPI2)!=RESET)
	{
		EXTI_ClearITPendingBit(EXTI_LINE_SPI2);  //��� EXTI_LINE_SPI2 �ϵ��жϱ�־λ
		NRF_IRQ();
	}
	OSIntExit();                                 /* Tell uC/OS-II that we are leaving the ISR          */	
}





















