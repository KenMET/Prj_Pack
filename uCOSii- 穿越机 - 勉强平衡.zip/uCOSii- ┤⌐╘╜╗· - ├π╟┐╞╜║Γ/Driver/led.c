#include "LED.h"

OS_STK LED_TASK_STK[LED_STK_SIZE];

unsigned char Color_User=0;


void Color(unsigned char Colo)
{
	switch(Colo)
	{
		case Green:	{	GREEN = 0;RED  	=	1;BLUE  = 1;	}break;
		case Blue:	{	GREEN = 1;RED  	=	1;BLUE  = 0;	}break;
		case Red:		{	GREEN = 1;RED  	=	0;BLUE  = 1;	}break;
		case Indigo:{	GREEN = 0;RED  	=	1;BLUE  = 0;	}break;
		case Yellow:{	GREEN = 0;RED  	=	0;BLUE  = 1;	}break;
		case Purple:{	GREEN = 1;RED  	=	0;BLUE  = 0;	}break;
		case White:	{	GREEN = 0;RED  	=	0;BLUE  = 0;	}break;
		case Black:	{	GREEN = 1;RED  	=	1;BLUE  = 1;	}break;
		default:		{	GREEN = 1;RED  	=	0;BLUE  = 1;	}break;
	}
}




void LED_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure_LED;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);
	
	GPIO_InitStructure_LED.GPIO_Pin = GPIO_Pin_13|GPIO_Pin_14|GPIO_Pin_15;			
  GPIO_InitStructure_LED.GPIO_Mode = GPIO_Mode_Out_PP;
  GPIO_InitStructure_LED.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(GPIOC, &GPIO_InitStructure_LED);
}


//LED����
void LED_Task(void *pdata)
{	 	
	Log_Uartx("Task Of LED Created...\n");
	TIM_Cmd(TIM3, ENABLE); 

	while(1)
	{
		if(Fly_Lock)
		{
			Color(Color_User);
			Delay_ms(80);
			Color(Black);
			Delay_ms(80);
			Color(Color_User);
			Delay_ms(80);
			Color(Black);
			Delay_ms(1500);		
		}
		else
		{
			Color(Color_User);
			Delay_ms(500);
			Color(Black);
			Delay_ms(500);
		}
	}
}




